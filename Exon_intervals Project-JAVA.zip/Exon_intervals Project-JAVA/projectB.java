// Kiranjit Kaur
// The objective of this program is to identify the start and end exon intervals

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.StringTokenizer;
//Declaring projectB class
public class projectB {
	public static void main(String args[]) {
		try {
			// Reading the input file from the current directory
			FileReader fr = new FileReader("updated_paired_end_reads.sam");
			BufferedReader reader = new BufferedReader(fr);   
			// Specifying the output file
			String fileName = "boundries.gtf"; 
			BufferedWriter writer = new BufferedWriter(new FileWriter(fileName,true));
			// Declaring string variable line to store each line 
			String line;
			Integer firstElement=0;
			// Setting the loop to read and process each line of the fie
			while ((line = reader.readLine()) != null) {
				// Dividing the line between tokens
				StringTokenizer tokens = new StringTokenizer(line);
				// For each token, loop through, need token number 4 and 6 
				int counter = 0;
					while(tokens.hasMoreTokens()) {
						String token = tokens.nextToken(); 
						counter++;
						// Reading the starting value stored in column 4 of the input file
						if(counter==4) {
							firstElement = Integer.parseInt(token);
						} 
						// Setting the loop to tokenize column 6 with M and N as the delimiters
						else if(counter==6) {
							StringTokenizer subTokens = new StringTokenizer(token,"MN");
							String subToken;
							Integer boundry=0;
							int counter2 = 0;
							int totalSubTokens = subTokens.countTokens();
							// For the case where no N is present such as lines containing 100M
							if(totalSubTokens==1) {
								// Decarlaring variables to store first and last boundries
								Integer b1=0;
								Integer b2=0;
								subToken = subTokens.nextToken();
								boundry = Integer.parseInt(subToken);
								b1 = firstElement;
								b2 = b1+ boundry -1;
								//Writing both boundries in the output file
								writer.write(b1+" "+b2);writer.newLine();
							}
							// For the case where both M and N values are present
							if(totalSubTokens>1) {
								Integer firstBoundry=0;
								Integer secBoundry = 0;
								while(subTokens.hasMoreTokens()) {
									subToken = subTokens.nextToken();counter2++;
									boundry = Integer.parseInt(subToken);        
									if(counter2==1) {
										firstBoundry = firstElement;
										secBoundry = firstBoundry + boundry -1;
										//Writing the boundries to the output file
										writer.write(firstBoundry+" "+secBoundry);writer.newLine();
									}
									if(counter2 != totalSubTokens) {
										firstBoundry = secBoundry + boundry + 1;
										// Storing the first boundry in this case
									}
								}
								//Writing the first and second boundries to the output file
								writer.write(firstBoundry+" "+(firstBoundry+boundry-1)); writer.newLine();
							}
						break;
						}
					}
    
    
			}
		writer.close();
		reader.close();
   
		} catch (Exception e) {
			e.printStackTrace();
		}  
	}
}
