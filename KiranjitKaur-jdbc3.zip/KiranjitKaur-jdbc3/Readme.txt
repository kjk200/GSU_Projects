CSC-6710 Database Systems - Readme File for JDBC-3 - Kiranjit Kaur

The JDBC-3 application has been implemented by creating a java file: OnlineBookStore.java. This .java file has been created using Eclipse SDK with JavaSE-1.6 JRE. The Oracle drivers ojdbc6.jar has been loaded in the referenced libraries of the project.

The username and passsword for accessing the database has been hard-coded in the code itself. 
 

