// The Online Book Store JDBC Project

import java.sql.*;
import java.sql.Date;
import java.util.Calendar;
import java.io.*;
import java.util.*;
import java.util.regex.Pattern;


// This class is use to define all the display menus such as Main Menu, Member Login Menu, Search Menu, Cart Menu
class BookStore {

	public BookStore() {
		// Creating an empty constructor
	}

	// This method defines the Main Menu
	public String displayMainMenu() {
		Scanner s = new Scanner(System.in);
		String choice = null;
		// This string variable will store the user choice
		System.out
				.println("***********************************************************************");
		System.out
				.println("***                                                                 ***");
		System.out
				.println("***               Welcome to the Online Book Store                  ***");
		System.out
				.println("***                                                                 ***");
		System.out
				.println("***********************************************************************");
		System.out.println();
		System.out
				.println("                          1. Member Login                              ");
		System.out.println();
		System.out
				.println("                          2. New Member Registration                   ");
		System.out.println();
		System.out
				.println("                          q. Quit                                      ");
		System.out.println();
		System.out.println();
		System.out.println("Type in your option: ");
		System.out.println();
		choice = s.next();
		return choice;
	} // End of displayMainMenu method

	// This method defines the Member Login Menu
	public String memberLoginMenu() {
		Scanner s1 = new Scanner(System.in);
		String option = null;
		// This string variable will store the option that the member selects
		System.out
				.println("***********************************************************************");
		System.out
				.println("***                                                                 ***");
		System.out
				.println("***               Welcome to the Online Book Store                  ***");
		System.out
				.println("***                         Member Menu                             ***");
		System.out
				.println("***                                                                 ***");
		System.out
				.println("***********************************************************************");
		System.out.println();
		System.out
				.println("                          1. Browse by Subject                         ");
		System.out.println();
		System.out
				.println("                          2. Search by Author/Title/Subject            ");
		System.out.println();
		System.out
				.println("                          3. View/Edit Shopping Cart                   ");
		System.out.println();
		System.out
				.println("                          4. Check Order Status                        ");
		System.out.println();
		System.out
				.println("                          5. Check Out                                 ");
		System.out.println();
		System.out
				.println("                          6. One Click Check Out                       ");
		System.out.println();
		System.out
				.println("                          7. View/Edit Personal Information            ");
		System.out.println();
		System.out
				.println("                          8. Logout                                    ");
		System.out.println();
		System.out.println();
		System.out.println("Type in your option: ");
		option = s1.next();
		if (!(Pattern.matches("[1-8]{1}", option))) {
			System.out.println("\nPlease enter a valid option.\n");
			memberLoginMenu();
		}
		return option;

	}// End of memberLoginMenu method
	
	// The method defines the search menu
	public String displaySearchMenu () {
		String option=null;
		System.out.println();
		System.out.println("1. Author Search");
		System.out.println("2. Title Search");
		System.out.println("3. Go Back to Member Menu.");
		Scanner s = new Scanner(System.in);
		option = s.next();
		if (!((option.equals("1"))||(option.equals("2"))||(option.equals("3")))) {
			System.out.println("\nPlease enter a valid choice.");
			displaySearchMenu();
		}
		return option;
		
	} // End of displaySearchMenu() method
	
	// This method displays the cart menu
	public String displayCartMenu () {
		String option = null;
		System.out.println("Enter d to delete item");
		System.out.println("e to edit cart or");
		System.out.println("q to go back to Menu: ");
		Scanner s = new Scanner(System.in);
		option = s.next();
		if (!((option.equals("d"))||(option.equals("e"))||(option.equals("q")))) {
			System.out.println("\nPlease enter a valid choice.\n");
			displayCartMenu();
		}
		
		return option;
	} // End of displayCartMenu() method
	

} // End of Class BookStore

public class OnlineBookStore {

	// This method will be used to read the input data
	static String readEntry(String input) {
		try {
			StringBuffer buffer = new StringBuffer();
			System.out.print(input);
			System.out.flush();
			int c = System.in.read();
			while (c != '\n') {
				buffer.append((char) c);
				c = System.in.read();
			}
			return buffer.toString().trim();
		} catch (IOException e) {
			return "";
		}
	} // End of method readEntry

	// This method is used to ensure that the member enters either y or n on the
	// credit card prompt
	static int creditCardPrompt(String input) {
		int i;
		if (input.equalsIgnoreCase("y")) {
			i = 0;
			return i;
		} else if (input.equalsIgnoreCase("n")) {
			i = 1;
			return i;
		} else {
			System.out.println();
			System.out.println("Please only enter y or n");
			System.out.println();
			//creditCardPrompt();
			String input1 = readEntry("Do you wish to store credit card information(y/n): ");
			return i = creditCardPrompt(input1);
		}
	} // End of method creditCardPrompt
	
	// This method is used to ensure that member enters y or n on the proceed to checkout prompt
	static int proceedCheckOut (String input) {
		int i;
		if (input.equalsIgnoreCase("y")) {
			i = 0;
			return i;
		} else if (input.equalsIgnoreCase("n")) {
			i = 1;
			return i;
		} else {
			System.out.println();
			System.out.println("Please only enter y or n");
			System.out.println();
			//creditCardPrompt();
			String input1 = readEntry("Proceed to check out(y/n): ");
			return i = proceedCheckOut(input1);
		}
	} // End of method proceedCheckOut()
	
	// This method is used to ensure that member enters y or n on the changing shipping address prompt
	static int newShippingAddress (String input) {
		
		int i;
		if (input.equalsIgnoreCase("y")) {
			i = 0;
			return i;
		} else if (input.equalsIgnoreCase("n")) {
			i = 1;
			return i;
		} else {
			System.out.println();
			System.out.println("Please only enter y or n");
			System.out.println();
			//creditCardPrompt();
			String input1 = readEntry("Do you want to enter new shipping address(y/n): ");
			return i = newShippingAddress(input1);
		}
		
	} // End of method newShippingAddress()

	// This method is used to validate the 16 digit numeric only credit card
	// format
	static int creditCardNumber(String input) {
		int i;
		if (Pattern.matches("[0-9]+", input)) {
			if (input.length() == 16) {
				i = 1;
				return i;
			} else {
				System.out.println("Invalid Entry.");
				String input1 = readEntry("Enter Credit Card Number: ");
				i = creditCardNumber(input1);
				return i;
			}
		} else {
			System.out.println("Invalid Entry.");
			String input2 = readEntry("Enter Credit Card Number: ");
			i = creditCardNumber(input2);
			return i;
		}
	} // End of method creditCardNumber
	
	// This method is used to get a count of any item from the database
	
	static int countItems (Statement s1, String s2) throws SQLException {
		int i=0;
		ResultSet r1 = s1.executeQuery(s2);
		while (r1.next()) {
			i=r1.getInt(1);
		}
		return i;
	} // End of method countItems
	
	// This method is used to display books information two at a time 
	static void displayItems (Statement s1, String s2, Connection conn, String memID, int thisCount) throws SQLException {
		ResultSet r1 = s1.executeQuery(s2);
		int subCount = 0;
		while (r1.next()) {
			System.out.println("Author: "+r1.getString(2));
			System.out.println("Title: "+r1.getString(3));
			System.out.println("ISBN: "+r1.getString(1));
			System.out.println("Price: "+r1.getString(4));
			System.out.println("Subject: "+r1.getString(5));
			System.out.println();
			subCount++;
			// The below IF statement includes code for entering ISBN after every 2 records or in case if only 1 record exists
			if ((subCount%2==0)||(thisCount==1)) {

					String response = readEntry("Enter ISBN to add to Cart or\nn Enter to browse or \nENTER to go back to menu:");
					
					if (response.equals("")) {
						// Go back to menu, if user presses Enter
						break;
					}
					else if (response.equals("n")) {
						// Continue to browse
						continue;
					}
					else {
						// Check if the ISBN is valid or not
						
						int checkISBN=0;
						while (checkISBN==0) {
						Statement stmt2 = conn.createStatement();
						// Below query is used to get info for the selected book
						String queryISBN = "select * from books where ISBN='"+response+"'";
						ResultSet setISBN = stmt2.executeQuery(queryISBN);
						while (setISBN.next()) {
							
							String authorName = setISBN.getString(2);
							String titleName = setISBN.getString(3);
							String price = setISBN.getString(4);
							String subject = setISBN.getString(5);
							checkISBN++;

							String qty = readEntry("Enter quantity: ");
							
							System.out.println();
							// The following query is used to add the book to the cart
							Statement stmtInsertCart = conn.createStatement();
							
							String queryInsertCart = "insert into cart values ('"+memID+"','"+response+"',"+qty+")";
							
							try {
								
								stmtInsertCart.executeUpdate(queryInsertCart);
							} catch (SQLException e) {
								System.out.println("Error adding selected book to the cart.");
								while (e != null) {
									System.out.println("Message: " + e.getMessage());
									e = e.getNextException();
								}
								return;
							}

							stmtInsertCart.close();
							System.out.println();
							break;
							
						}
						if (checkISBN==0) {
							System.out.println();
							System.out.println("The ISBN that you have entered is not correct. Cart has not been updated.");
							System.out.println();

							checkISBN=0;
							break;
						}
						stmt2.close();
						
					}
					continue;	
				}
				
			}
			
		}
	} // End of method displayItems
	
	// This method is used to display the orders
	static void placedOrder(Connection conn, String memUser, String userFirstName, String userLastName) throws SQLException {
		

		System.out.println("\n\n");
		System.out.println("Orders placed by "+userFirstName+" "+userLastName);
		System.out.println();
		System.out.println("-------------------------------------------------------------------------------------------------------");
		System.out.printf("%-30.30s %-30.30s %-30.30s%n", "Order No", "Received Date", "Shipped Date");;
		// The following query is used to get the information about the Orders of this member
		Statement getOrderStmt = conn.createStatement();
		String getOrderString = "select ono, received, shipped from orders where userid='"+memUser+"'"+" order by ono";
		ResultSet getOrderSet = getOrderStmt.executeQuery(getOrderString);
		int ordernum = 0;
		String rcvdDate = null, shipDate = null, rcvdFormattedDate=null, shipFormattedDate=null;
		while (getOrderSet.next()) {
			
			ordernum = getOrderSet.getInt(1);
			rcvdDate = getOrderSet.getDate(2).toString();
			shipDate = getOrderSet.getDate(3).toString();
			// The below substring functions are used to display the date in same format as specified in example
			rcvdFormattedDate = rcvdDate.substring(5, 7)+"-"+rcvdDate.substring(8)+"-"+rcvdDate.substring(0,4);
			shipFormattedDate = shipDate.substring(5, 7)+"-"+shipDate.substring(8)+"-"+shipDate.substring(0,4);
			
			System.out.printf("%-30.30s %-30.30s %-30.30s%n", ordernum, rcvdFormattedDate, shipFormattedDate);
		}
		getOrderStmt.close();
		System.out.println();
		
	} // End of placedOrder method
	
	// This method is used to display order details for a particular order number
	static void displayOrderDetails (Connection conn, String memUser, String choice, String userFirstName, String sfName, String userLastName, String slName, String userAddress, String sAddress, String userCity, String sCity, String userState, String sState, int userZip, int sZip) throws SQLException {
		

				String fullName = userFirstName+" "+userLastName;
				String sfullName = sfName + " " + slName;
				
				System.out.printf("%-30.30s %-30.30s%n", "Shipping Address", "Billing Address");
				System.out.printf("%-30.30s %-30.30s%n", fullName, sfullName);
				System.out.printf("%-30.30s %-30.30s%n", userAddress, sAddress);
				System.out.printf("%-30.30s %-30.30s%n","	"+userCity, "	"+sCity);
				System.out.printf("%-30.30s %-30.30s%n","	"+userState+" "+userZip, "	"+sState+" "+sZip);
				System.out.println();
				System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.printf("%-30.30s %-30.30s %-30.30s %-30.30s %-30.30s%n", "ISBN", "Title", "$", "Qty", "Total");
				// Below query is used to get information about current order
				Statement getOdetailsStmt4 = conn.createStatement();
				String getOdetailsString4 = "select o.isbn, b.title, o.price, o.qty, sum(o.qty*o.price) from odetails o, books b where o.isbn=b.isbn and o.ono="+choice+" group by o.isbn, b.title, o.price, o.qty";
				ResultSet getOdetailsSet4 = getOdetailsStmt4.executeQuery(getOdetailsString4);
				while (getOdetailsSet4.next()){
					String oISBN = getOdetailsSet4.getString(1).trim();
					String bTitle = getOdetailsSet4.getString(2).trim();
					String oPrice = getOdetailsSet4.getString(3);
					String oQty = getOdetailsSet4.getString(4);
					String total = getOdetailsSet4.getString(5);

					System.out.printf("%-30.30s %-30.30s %-30.30s %-30.30s %-30.30s%n", oISBN, bTitle, oPrice, oQty, total);

				}
				System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
				getOdetailsStmt4.close();
				// The below query is used to get info about Total amount due
				Statement getTotalStmt4 = conn.createStatement();
				String getTotalString4 = "select sum(qty*price) from odetails where ono="+choice;
				ResultSet getTotalSet4 = getTotalStmt4.executeQuery(getTotalString4);
				while (getTotalSet4.next()){

					System.out.printf("%-30.30s %30s%n", "Total", "                                                                                 $"+getTotalSet4.getString(1));
				}
				System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
			
			
		
	} // End of displayOrderDetails method
	
	// This method is used to display the current cart details
	static void displayCartDetails (Statement stmt, String str, Statement stmt2, String str2) throws SQLException {
		
		System.out.println();
		System.out.printf("%-30.30s %-30.30s %-30.30s %-30.30s %-30.30s%n", "ISBN", "Title", "$", "Qty", "Total");
		System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
		ResultSet rSet = stmt.executeQuery(str);
		while (rSet.next()) {
			String cISBN = rSet.getString(1).trim();
			String bTitle = rSet.getString(2).trim();
			String bPrice = rSet.getString(3);
			String oQty = rSet.getString(4);
			String total = rSet.getString(5);

			System.out.printf("%-30.30s %-30.30s %-30.30s %-30.30s %-30.30s%n", cISBN, bTitle, bPrice, oQty, total);
		}
		
		System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
		
		ResultSet rSet2 = stmt2.executeQuery(str2);
		while (rSet2.next()) {
			
			System.out.printf("%-30.30s %30s%n", "Total", "                                                                                 $"+rSet2.getString(1));
		}
		
		System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
	} // End of method displayCartDetails()
	
	// This method is used to run any SQL query	
	static void runQuery (Statement stmt, String str, Connection conn) throws SQLException {
		
		conn.setAutoCommit(false);
		// The following query is used to empty the contents of the cart
				
		int nrows;
		try {
			
			nrows = stmt.executeUpdate(str);
		} catch (SQLException e) {
			System.out.println("This Operation could not be performed.");
			while (e != null) {
				System.out.println("Message: " + e.getMessage());
				e = e.getNextException();
			}
			conn.rollback();
			return;
		}

		conn.commit();
		conn.setAutoCommit(true);
	} // End of method runQuery()
	
	// This method is used to get the month in a word format which is used to store the date
	static String getMonth (String tempMonth) {
		String month = null;
		if (tempMonth.equals("01")) {
			month="JAN";
		}
		else if (tempMonth.equals("02")) {
			month="FEB";
		}
		else if (tempMonth.equals("03")) {
			month="MAR";
		}
		else if (tempMonth.equals("04")) {
			month="APR";
		}
		else if (tempMonth.equals("05")) {
			month="MAY";
		}
		else if (tempMonth.equals("06")) {
			month="JUN";
		}
		else if (tempMonth.equals("07")) {
			month="JUL";
		}
		else if (tempMonth.equals("08")) {
			month="AUG";
		}
		else if (tempMonth.equals("09")) {
			month="SEP";
		}
		else if (tempMonth.equals("10")) {
			month="OCT";
		}
		else if (tempMonth.equals("11")) {
			month="NOV";
		}
		else if (tempMonth.equals("12")) {
			month="DEC";
		}
		return month;
	} // End of getMonth()	


	// MAIN method
	public static void main(String[] args) throws SQLException, IOException {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Could not load the driver.");
		}

		// Open the connection to the tinman database
		Connection conn = DriverManager.getConnection(
				"jdbc:oracle:thin:@tinman.cs.gsu.edu:1522:tinman", "kkaur6",
				"dumka2013");
				
		// Create an object b1 from the BookStore class
		BookStore b1 = new BookStore();
		// String variable to store input response from the user
		String input;
		input = b1.displayMainMenu();
		// Implementing a while loop to run the program until user quits by
		// entering q or Q
		while (!(input.equalsIgnoreCase("q"))) {
			// If the input is 1, launch the Member Login
			if (input.equals("1")) {
				String memberInput;
				System.out.println();
				String memUser = readEntry("Enter userID: ");
				String memPassword = readEntry("Enter password: ");
				Statement validateUserStmt = conn.createStatement();
				String validateUserIDQuery = "select password from members where userid='"
						+ memUser + "'";
				int userCounter = 0;
				ResultSet matchPassword = validateUserStmt.executeQuery(validateUserIDQuery);
				
				// This loop is used to validate if the userID exists and also
				// if the password is correct
				while (matchPassword.next()) {
					String getPassword = matchPassword.getString(1);
					if (getPassword.equals(memPassword)) {						
						userCounter = 1;
					} else {
						userCounter = 2;
					}
				}
				validateUserStmt.close();
				// Display this message if userID does not exist
				if (userCounter == 0) {
					System.out.println();
					System.out
							.println("The user ID that you entered does not exist. Please re-enter the user ID and password.");
					System.out.println();
				}

				// Display Member Login Menu
				if (userCounter == 1) {
				
						
					memberInput = b1.memberLoginMenu();
					
					// Implementing Browse By Subject
					while (memberInput.equals("1")) {
						// Code for Browse by Subject
						System.out.println();
						// This query determines number of distinct subjects in the database
						Statement countSubStmt = conn.createStatement();
						String countSubString = "select count(distinct subject) from books";
						int count = countItems(countSubStmt, countSubString);
						countSubStmt.close();
						// This Array is used to store the names of different subjects
						String subjectArray[] = new String[count];
						// This query is used to display all the distinct subjects
						Statement listSubStmt = conn.createStatement();
						String listSubString = "select distinct subject from books order by subject";
						ResultSet subjectList = listSubStmt.executeQuery(listSubString);
						
						int n = 1;
						while (subjectList.next()) {
							// Code for displaying the list of subjects
							
							System.out.println(n+": "+subjectList.getString(1));
							subjectArray [n-1] = subjectList.getString(1);
							System.out.println();
							n++;
						}
						listSubStmt.close();
						// The subCount variable is used to display the ISBN message after every 2 records
						int subCount = 0;
						System.out.println("Enter your choice: ");
						
						Scanner memberChoice = new Scanner (System.in);
						int choice = memberChoice.nextInt();
						
						System.out.println();
						// This If statement ensures that member enters the correct number for selecting a subject
						if (choice <= subjectArray.length) {
							Statement countThisStmt = conn.createStatement();
							// This query determines number of books for selected subject
							String countThisString = "select count(*) from books where subject='"+subjectArray[choice-1]+"'";
							ResultSet countThisList = countThisStmt.executeQuery(countThisString);
							int thisCount = countItems(countThisStmt, countThisString);
							countThisStmt.close();
							System.out.println(thisCount+" books available on this Subject");
							System.out.println();
							System.out.println();
							// The following query is used to display the records for each book
							Statement displayThisStmt = conn.createStatement();
							String displayThisString = "select * from books where subject = '"+subjectArray[choice-1]+"'";
							displayItems(displayThisStmt, displayThisString, conn, memUser, thisCount);
							displayThisStmt.close();
	
						}
						else {
							// code for case where user does not select correct option
							System.out.println("Please enter a correct choice. Your input does not match any subjects.");
							continue;
						}
						

						System.out.println();
						memberInput = b1.memberLoginMenu();
						
					} // End of While Loop for Option 1
					
					// Implementing SEARCH BY AUTHOR/TITLE
					
					while (memberInput.equals("2")) {
						
						String option = b1.displaySearchMenu();
						// Search by Author						
						if (option.equals("1")) {
							
							String author = readEntry("Enter name or part of the name: ");
							// The below statement is used to count number of Books
							Statement countAuthorStmt = conn.createStatement();							
							String countAuthorString = "select count(*) from books where author like '%"+author+"%'";
							int searchCount = countItems(countAuthorStmt, countAuthorString);
							System.out.println(searchCount+" books found");
							countAuthorStmt.close();
							// The below statement is used to display the books
							Statement displayAuthorStmt = conn.createStatement();
							String displayAuthorString = "select * from books where author like '%"+author+"%'";
							displayItems(displayAuthorStmt, displayAuthorString, conn, memUser, searchCount);
							displayAuthorStmt.close();
							memberInput = b1.memberLoginMenu();
						}
						// Search by Title
						if (option.equals("2")) {
							
							String title = readEntry("Enter title or part of the title: ");
							// The below statement is used to count number of books
							Statement countTitleStmt = conn.createStatement();
							String countTitleString = "select count(*) from books where title like '%"+title+"%'";
							
							int searchCount = countItems(countTitleStmt, countTitleString);
							System.out.println(searchCount+" books found");
							countTitleStmt.close();
							// The below statement is used to display the books
							Statement displayTitleStmt = conn.createStatement();
							String displayTitleString = "select * from books where title like '%"+title+"%'";
							displayItems(displayTitleStmt, displayTitleString, conn, memUser, searchCount);
							displayTitleStmt.close();
							memberInput = b1.memberLoginMenu();
						}
						
						if (option.equals("3")) {							
							memberInput = b1.memberLoginMenu();						
						}
						
						System.out.println();

					} // End of While Loop for Option 2
					
					
					// Code for Edit and View cart contents
					while (memberInput.equals("3")) {
						
						System.out.println();
						// The below statement is used to find number of items in cart
						Statement countCartStmt = conn.createStatement();
						String countCartString = "select count(*) from cart where userid='"+memUser+"'";
						
						int cartCount = countItems(countCartStmt, countCartString);
						countCartStmt.close();
						// If the cart is empty, display this message
						if (cartCount==0) {
							System.out.println("\nThere are no items in the cart for this user.\n");
							memberInput = b1.memberLoginMenu();
						}
						// If the card is not empty, continue to display the cart details
						else {
							Statement cartDisplayStmt = conn.createStatement();
							String cartDisplayString = "select c.isbn, b.title, b.price, c.qty, sum(b.price * c.qty) from cart c, books b where c.isbn=b.isbn and c.userid='"+memUser+"' group by c.isbn, b.title, b.price, c.qty";
							
							Statement cartTotalStmt = conn.createStatement();
							String cartTotalString = " select sum (c.qty*b.price) from cart c, books b where c.isbn=b.isbn and c.userid='"+memUser+"'";
							
							System.out.println("\nCurrent Cart Contents: \n");
							displayCartDetails(cartDisplayStmt, cartDisplayString, cartTotalStmt, cartTotalString);
							System.out.println("\n\n");
							
							cartDisplayStmt.close();
							cartTotalStmt.close();
							
							String cartChoice = b1.displayCartMenu();
							// Delete an item from the cart
							if (cartChoice.equals("d")) {
								String cartISBN = readEntry("Enter isbn of item: ");
								Statement deleteCartStmt = conn.createStatement();
								String deleteCartString = "delete from cart where isbn='"+cartISBN+"' and userid='"+memUser+"'";
								
								runQuery(deleteCartStmt, deleteCartString, conn);
								deleteCartStmt.close();
								
								System.out.println("Delete Item Completed");
								int var = 0;
								String temp = readEntry("Press enter to go back to Menu ");
								while (var == 0) {
									// Below If statement verifies that User pressed enter
									if (temp.equals("")) {
										//memberInput = b1.memberLoginMenu();
										var = 1;
									} else {
										System.out.println();
										System.out
										.println("No other key presses besides ENTER are allowed.");
										System.out.println();
										temp = readEntry("Press enter to go back to Menu ");
									}

								}
								memberInput = b1.memberLoginMenu();
							}
							// Edit the quantity of the books in the cart
							else if (cartChoice.equals("e")) {
								String editISBN = readEntry("Enter isbn of item: ");
								String newQty = readEntry("Enter New Quantity: ");
								
								Statement editCartStmt = conn.createStatement();
								String editCartString = "update cart set qty="+newQty+" where isbn='"+editISBN+"' and userid='"+memUser+"'";
								
								runQuery(editCartStmt, editCartString, conn);
								editCartStmt.close();
								
								System.out.println("Edit Item Completed");
								int var = 0;
								String temp = readEntry("Press enter to go back to Menu ");
								while (var == 0) {
									// Below If statement verifies that User pressed enter
									if (temp.equals("")) {
										//memberInput = b1.memberLoginMenu();
										var = 1;
									} else {
										System.out.println();
										System.out
										.println("No other key presses besides ENTER are allowed.");
										System.out.println();
										temp = readEntry("Press enter to go back to Menu ");
									}

								}
								memberInput = b1.memberLoginMenu();
							}
							// Quit to Member Menu again							
							else if (cartChoice.equals("q")) {
								memberInput = b1.memberLoginMenu();
							
							}
							
						} // End of Else
						
					} // End of While for option 3
					
					// Implementing Check Order Status
					while (memberInput.equals("4")) {
						
						
						String userFirstName=null, userLastName=null, userAddress=null, userCity=null, userState=null;
						int userZip=0;
						// The following query is used to get the data for the current member
						Statement getUserStmt = conn.createStatement();
						String getUserString = "select fname, lname, address, city, state, zip from members where userid='"+memUser+"'";
						ResultSet getUserSet = getUserStmt.executeQuery(getUserString);
						while (getUserSet.next()) {
							userFirstName = getUserSet.getString(1);
							userLastName = getUserSet.getString(2);
							userAddress = getUserSet.getString(3);
							userCity = getUserSet.getString(4);
							userState = getUserSet.getString(5);
							userZip = getUserSet.getInt(6);
						}
						getUserStmt.close();
											
						// The below statement is used to count the number of orders for this member
						Statement checkOrderStmt = conn.createStatement();
						String checkOrderString = "select count(*) from orders where userid='"+memUser+"'";
						ResultSet checkOrderSet = checkOrderStmt.executeQuery(checkOrderString);
						int userOrderCount = 0;
						while(checkOrderSet.next()) {
							userOrderCount = checkOrderSet.getInt(1);
						}
						
						checkOrderStmt.close();
						// Display this message if this user does not have any existing orders
						if (userOrderCount == 0) {
							System.out.println("\nThis user does not have any existing orders.\n");
							memberInput = b1.memberLoginMenu();
						}
						
						// Continue to display order details if member has existing orders

						else {

							placedOrder(conn, memUser, userFirstName, userLastName);

							String choice = readEntry("Enter the Order No to display its details or (q) to quit:");
							if (choice.equalsIgnoreCase("q")) {
								memberInput = b1.memberLoginMenu();
								//continue;
							}
							else {
								
								int checkCounter = 0;
								String getUserID = null;
								// The below query is used to verify that a valid order number has been entered
								Statement verifyOrderStmt = conn.createStatement();
								String verifyOrderString = "select userid from orders where ono="+choice;
								ResultSet verifyOrderSet = verifyOrderStmt.executeQuery(verifyOrderString);
								while (verifyOrderSet.next()) {
									getUserID = verifyOrderSet.getString(1);
								}
								
								if ((getUserID.equals(memUser))) {
									checkCounter = 1;
								}
								
								verifyOrderStmt.close();
								
								// Below message is displayed is member selects an incorrect order number

								if (checkCounter==0) {
									System.out.println("\nThe order number that you entered is invalid. \n");
									continue;
								}
								
								else {
									
									String sAddress=null, sCity=null, sState=null;
									int sZip = 0;
									// The below statement is used to get shipping address
									Statement getShipStmt = conn.createStatement();
									String getShipString="select shipAddress, shipCity, shipState, shipZip from orders where ono="+choice;
									ResultSet getShipSet = getShipStmt.executeQuery(getShipString);
									while (getShipSet.next()) {
										sAddress = getShipSet.getString(1);
										sCity = getShipSet.getString(2);
										sState = getShipSet.getString(3);
										sZip = getShipSet.getInt(4);
									}

									System.out.println();
									String invoiceString="Details For Order No. "+choice;
									System.out.println("\t\t\t"+invoiceString+"\n");
									
									String sfName = userFirstName, slName = userLastName;

									displayOrderDetails(conn, memUser, choice, userFirstName, sfName, userLastName, slName, userAddress, sAddress, userCity, sCity, userState, sState, userZip, sZip);

								}
						
							System.out.println("\n");
							int var = 0;
							String temp =  readEntry("Press enter to go back to Menu ");
							while (var == 0) {
								// Below If statement verifies that User pressed enter
								if (temp.equals("")) {
									//memberInput = b1.memberLoginMenu();
									var = 1;
								} else {
									System.out.println();
									System.out
									.println("No other key presses besides ENTER are allowed.");
									System.out.println();
									temp = readEntry("Press enter to go back to Menu ");
								}

							}
							
							memberInput = b1.memberLoginMenu();
							} // End of Else



						} // End of Else

					} // End of While Loop for option 4
					
					
					// Implementing Check Out
					
					while (memberInput.equals("5")) {
						
						System.out.println();
						// Below statement is used to count number of items in the cart
						Statement checkoutCartStmt = conn.createStatement();
						String checkoutCartString = "select count(*) from cart where userid='"+memUser+"'";
						
						int checkoutCount = countItems(checkoutCartStmt, checkoutCartString);
						checkoutCartStmt.close();
						// Display this message is no items exist in the cart
						if (checkoutCount==0) {
							System.out.println("\nThere are no items in the cart for this user.\n");
							//memberInput = b1.memberLoginMenu();
						}
						else {
							
							Statement cartDisplayStmt = conn.createStatement();
							String cartDisplayString = "select c.isbn, b.title, b.price, c.qty, sum(b.price * c.qty) from cart c, books b where c.isbn=b.isbn and c.userid='"+memUser+"' group by c.isbn, b.title, b.price, c.qty";
							
							Statement cartTotalStmt = conn.createStatement();
							String cartTotalString = " select sum (c.qty*b.price) from cart c, books b where c.isbn=b.isbn and c.userid='"+memUser+"'";
							// Displaying Current Cart Contents
							System.out.println("\nCurrent Cart Contents: \n");
							displayCartDetails(cartDisplayStmt, cartDisplayString, cartTotalStmt, cartTotalString);
							System.out.println("\n\n");
							
							cartDisplayStmt.close();
							cartTotalStmt.close();
							Statement userIDStmt = conn.createStatement();
							String userIDString = "select * from members where userid='"+memUser+"'";
							ResultSet userIDSet = userIDStmt.executeQuery(userIDString);
							String userAddress=null, userCity=null, userState=null, userFirstName=null, userLastName=null;
							int userZip=0;
							while (userIDSet.next()) {
								userFirstName=userIDSet.getString(1);
								userLastName=userIDSet.getString(2);
								userAddress=userIDSet.getString(3);
								userCity=userIDSet.getString(4);
								userState=userIDSet.getString(5);
								userZip=userIDSet.getInt(6);
							}
							userIDStmt.close();
							
							Statement countRecords = conn.createStatement();
							String countOneClick = "select count (*) from orders";
							int orderCount = countItems(countRecords, countOneClick);
							
							countRecords.close();
							
							String sfName=null, slName=null, sAddress=null, sCity=null, sState=null;
							int sZip = 0;
							// Prompting the member to proceed to check out
							String proceed = "Proceed to check out (Y/N): ";
							int checkOut = proceedCheckOut(proceed);
							if (checkOut==0) {
								// Prompting the member to enter new shipping address
								String shippingString = "Do you want to enter new shipping address (y/n): ";
								int shipping = newShippingAddress(shippingString);
								if (shipping == 0) {
									sfName = readEntry("Enter first name: ");
									slName = readEntry("Enter last name: ");
									sAddress = readEntry("Enter street: ");
									sCity = readEntry("Enter city: ");
									sState = readEntry("Enter state: ");
									Scanner s = new Scanner(System.in);
									System.out.println("Enter zip: ");
									sZip = s.nextInt();							
										//continue;									
									}

								//}
								if (shipping == 1) {
									sfName = userFirstName;
									slName = userLastName;
									sAddress = userAddress;
									sCity = userCity;
									sState = userState;
									sZip = userZip;
									//continue;
								}
								
								String prompt1 = readEntry("Do you want to enter new CreditCard Number(y/n): ");
								String cardType = null, cardNumber = null;
								int counter1 = creditCardPrompt(prompt1);
								if (counter1 == 0) {
									cardType = readEntry("Enter type of credit card (amex/visa): ");
									String cardNumberTemp = readEntry("Enter Credit Card Number: ");
									int counter2 = creditCardNumber(cardNumberTemp);
									if (counter2 == 1) {
										cardNumber = cardNumberTemp;
									}
									Statement updateCardStmt = conn.createStatement();
									String updateCardString = "update members set creditcardtype='"+cardType+"', creditcardnumber='"+cardNumber+"' where userid='"+memUser+"'";
									runQuery(updateCardStmt, updateCardString, conn);
									System.out.println("\nNew credit card has been updated.\n");
									updateCardStmt.close();
								}
								
								if (counter1 == 1) {
									
									System.out.println("Existing card will be used.");
								}
								
								Calendar cal = Calendar.getInstance();
								
								Date date = new Date(cal.getTime().getTime());

								String tempDate = date.toString();
								String year = tempDate.substring(0,4);
								String tempMonth = tempDate.substring(5,7);
								String day = tempDate.substring(8,10);
								
								String month=getMonth(tempMonth);
					
								String receivedDate = day+"-"+month+"-"+year;
								String shippedDate = receivedDate;
								

								int ono = orderCount+1;
																
								// Insert record into Orders table
								Statement createOrderStmt = conn.createStatement();
								String createOrderString = "insert into orders values ('"+memUser+"',"+ono+",'"+receivedDate+"','"+shippedDate+"','"+sAddress+"','"+sCity+"','"+sState+"',"+sZip+")";
								
								try {
									
									createOrderStmt.executeUpdate(createOrderString);
									
								
								} catch (SQLException e) {
									System.out.println("Error creating a new Order");
									while (e != null) {
										System.out.println("Message: " + e.getMessage());
										e = e.getNextException();
									}
									return;
								}
								createOrderStmt.close();
								
								// Inserting record into Odetails table
								Statement cartContentStmt = conn.createStatement();
								String cartContentString = "select * from cart where userid='"+memUser+"'";
								ResultSet cartContentSet = cartContentStmt.executeQuery(cartContentString);
								String getISBN = null, getPrice=null, getQty=null;
								
								while (cartContentSet.next()) {
									getISBN=cartContentSet.getString(2);
									getQty = cartContentSet.getString(3);
									// Get the price of the book from books table
									Statement getPriceStmt = conn.createStatement();
									String getPriceString = "select price from books where ISBN='"+getISBN+"'";
									ResultSet getPriceSet = getPriceStmt.executeQuery(getPriceString);
									while (getPriceSet.next()) {
										getPrice = getPriceSet.getString(1);
									}
									getPriceStmt.close();

									// Adding entry into the Odetails table

									Statement createOdetailsStmt = conn.createStatement();
									String createOdetailsString = "insert into odetails values ("+ono+",'"+getISBN+"',"+getQty+",'"+getPrice+"')";

									try {
										createOdetailsStmt.executeUpdate(createOdetailsString);
										
									} catch (SQLException e) {
										System.out.println("Error creating a new Order Detail entry");
										while (e != null) {
											System.out.println("Message: " + e.getMessage());
											e = e.getNextException();
										}
										return;
									}
									createOdetailsStmt.close();
									orderCount = ono;

								}
								
								cartContentStmt.close();
							
							// Display the order detail

							String invoiceString="Invoice For Order Number "+orderCount;
							System.out.println("\n\n\t\t\t"+invoiceString+"\n");
							
							String choice = orderCount+"";
							choice.trim();
							displayOrderDetails(conn, memUser, choice, userFirstName, sfName, userLastName, slName, userAddress, sAddress, userCity, sCity, userState, sState, userZip, sZip);
							// Emptying the contents of the cart
							Statement emptyCartStmt = conn.createStatement();
							String emptyCartString = "delete from cart where userid='"+memUser+"'";
							runQuery(emptyCartStmt, emptyCartString, conn);

							emptyCartStmt.close();
							System.out.println();
							//memberInput = b1.memberLoginMenu();
								
							} // End of checkout = 0
							if (checkOut==1) {
								System.out.println();
								//continue;
							}
						
						} // End of Else
						
						memberInput = b1.memberLoginMenu();
						
					}
					
					
					// Implementing One Click Check Out
					
					while (memberInput.equals("6")) {
						// Finding existing count of orders in the database
						// This count will be used to assign unique order number
						Statement countRecords = conn.createStatement();
						String countOneClick = "select count (*) from orders";
						int orderCount = countItems(countRecords, countOneClick);
						
						countRecords.close();
						// The below query is used to get the current count from the cart
						Statement countCartStmt = conn.createStatement();
						String countCartString = "select count(*) from cart";
						ResultSet countCartRset = countCartStmt.executeQuery(countCartString);
						int cartCount = 0;
						while (countCartRset.next()) {
							cartCount = countCartRset.getInt(1);
						}
						if (cartCount==0) {
							System.out.println("The cart is empty. No items found.");
						}
						else {
							// Getting info about the userid
							Statement userIDStmt = conn.createStatement();
							String userIDString = "select * from members where userid='"+memUser+"'";
							ResultSet userIDSet = userIDStmt.executeQuery(userIDString);
							String userAddress=null, userCity=null, userState=null, userFirstName=null, userLastName=null;
							int userZip=0;
							while (userIDSet.next()) {
								userFirstName=userIDSet.getString(1);
								userLastName=userIDSet.getString(2);
								userAddress=userIDSet.getString(3);
								userCity=userIDSet.getString(4);
								userState=userIDSet.getString(5);
								userZip=userIDSet.getInt(6);
							}
							String sfName = userFirstName, slName=userLastName, sAddress=userAddress, sCity = userCity, sState = userState;
							int sZip = userZip;
							userIDStmt.close();
							// Getting info about current date which will be set as Received and Shipping Date
							Calendar cal = Calendar.getInstance();
				
							Date date = new Date(cal.getTime().getTime());

							String tempDate = date.toString();
							String year = tempDate.substring(0,4);
							String tempMonth = tempDate.substring(5,7);
							String day = tempDate.substring(8,10);
							
							String month=getMonth(tempMonth);
							
							String receivedDate = day+"-"+month+"-"+year;
							String shippedDate = receivedDate;
							

							int ono = orderCount+1;
							
							// Insert record into Orders table
							Statement createOrderStmt = conn.createStatement();
							String createOrderString = "insert into orders values ('"+memUser+"',"+ono+",'"+receivedDate+"','"+shippedDate+"','"+sAddress+"','"+sCity+"','"+sState+"',"+sZip+")";
							
							try {
								
								createOrderStmt.executeUpdate(createOrderString);
								
							
							} catch (SQLException e) {
								System.out.println("Error creating a new Order");
								while (e != null) {
									System.out.println("Message: " + e.getMessage());
									e = e.getNextException();
								}
								return;
							}
							createOrderStmt.close();
							
							// Inserting record into Odetails table
							Statement cartContentStmt = conn.createStatement();
							String cartContentString = "select * from cart where userid='"+memUser+"'";
							ResultSet cartContentSet = cartContentStmt.executeQuery(cartContentString);
							String getISBN = null, getPrice=null, getQty=null;
							
							while (cartContentSet.next()) {
								getISBN=cartContentSet.getString(2);
								getQty = cartContentSet.getString(3);
								// Get the price of the book from books table
								Statement getPriceStmt = conn.createStatement();
								String getPriceString = "select price from books where ISBN='"+getISBN+"'";
								ResultSet getPriceSet = getPriceStmt.executeQuery(getPriceString);
								while (getPriceSet.next()) {
									getPrice = getPriceSet.getString(1);
								}
								getPriceStmt.close();

								// Adding entry into the Odetails table

								Statement createOdetailsStmt = conn.createStatement();
								String createOdetailsString = "insert into odetails values ("+ono+",'"+getISBN+"',"+getQty+",'"+getPrice+"')";

								try {
									createOdetailsStmt.executeUpdate(createOdetailsString);
									
								} catch (SQLException e) {
									System.out.println("Error creating a new Order Detail entry");
									while (e != null) {
										System.out.println("Message: " + e.getMessage());
										e = e.getNextException();
									}
									return;
								}
								createOdetailsStmt.close();
								orderCount = ono;

							}
							
							cartContentStmt.close();
						
						// Display the order detail

						String invoiceString="Invoice For Order Number "+orderCount;
						System.out.println("\n\n\t\t\t"+invoiceString+"\n");
						
						String choice = orderCount+"";
						choice.trim();
						displayOrderDetails(conn, memUser, choice, userFirstName, sfName, userLastName, slName, userAddress, sAddress, userCity, sCity, userState, sState, userZip, sZip);
						// Emptying the contents of the cart
						Statement emptyCartStmt = conn.createStatement();
						String emptyCartString = "delete from cart where userid='"+memUser+"'";
						runQuery(emptyCartStmt, emptyCartString, conn);

						emptyCartStmt.close();
						System.out.println();
						memberInput = b1.memberLoginMenu();
						//break;

					}
					
					while (memberInput.equals("7")) {
						System.out.println();
						System.out
								.println("This feature has not been implemented yet.");
						System.out
								.println("The feature is not required for the project submission");
						System.out.println();
						memberInput = b1.memberLoginMenu();
					}

					// If the member opts to log out
					while (memberInput.equals("8")) {
						String temp;
						// This variable will be used to check if user pressed
						// Enter to go back to Main Menu
						Scanner sTemp = new Scanner(System.in);
						System.out.println("You have successfully logged out!");
						System.out.println("Press enter to go back to Menu ");
						temp = sTemp.nextLine();
						// Below If statement verifies that User pressed enter
						if (temp.equals("")) {
							input = b1.displayMainMenu();
							break;
						} else {
							System.out.println();
							System.out
									.println("No other key presses besides ENTER are allowed.");
							System.out.println();
							//memberInput = b1.memberLoginMenu();
						}

					} // End of while block for option 8
					
						
					}//memberInput = b1.memberLoginMenu();

				} // End of If block for userCounter==1
				else if (userCounter == 2) {

					System.out.println();
					System.out
							.println("The password that you entered for "
									+ memUser
									+ " does not match our records. Please re-enter the info.");
					System.out.println();

				} // End of else if block
		
			} // End of IF block for Member Login

			// New Member Registration
			else if (input.equals("2")) {
				System.out.println("Welcome to Online Book Store ");
				System.out.println("New Member Registration");
				System.out.println();

				String fName = readEntry("Enter first name: ");
				String lName = readEntry("Enter last name: ");
				String sAddress = readEntry("Enter street address: ");
				String city = readEntry("Enter City: ");
				String state = readEntry("Enter State: ");
				String zip = readEntry("Enter zip: ");
				String phone = readEntry("Enter phone: ");
				String email = readEntry("Enter email address: ");
				String userID = readEntry("Enter userID: ");
				String password = readEntry("Enter password: ");
				String prompt1 = readEntry("Do you wish to store credit card information(y/n): ");
				String cardType = null, cardNumber = null;
				int counter1 = creditCardPrompt(prompt1);
				if (counter1 == 0) {
					cardType = readEntry("Enter type of credit card (amex/visa): ");
					String cardNumberTemp = readEntry("Enter Credit Card Number: ");
					int counter2 = creditCardNumber(cardNumberTemp);
					if (counter2 == 1) {
						cardNumber = cardNumberTemp;
					}
				}
				if (counter1 == 1) {
					cardType = "";
					cardNumber = "";
				}
				// The following check is implemented to ensure that userID is
				// not already being used
				Statement checkUserIDStmt = conn.createStatement();
				String checkUserIDQuery = "select fname from members where userid='"
						+ userID + "'";
				int countUserID = 0;
				ResultSet userIDRset = checkUserIDStmt.executeQuery(checkUserIDQuery);
				while (userIDRset.next()) {
					countUserID = 1;
				}
				checkUserIDStmt.close();
				// If userID is validated, proceed with adding the new member
				if (countUserID == 0) {
					
					Statement newMemberStmt = conn.createStatement();

					String newMemberQuery = "insert into members values ("
							+ "'"
							+ fName
							+ "','"
							+ lName
							+ "','"
							+ sAddress
							+ "','"
							+ city
							+ "','"
							+ state
							+ "','"
							+ zip
							+ "','"
							+ phone
							+ "','"
							+ email
							+ "','"
							+ userID
							+ "','"
							+ password
							+ "','"
							+ cardType
							+ "','"
							+ cardNumber
							+ "')";

					try {
						newMemberStmt.executeUpdate(newMemberQuery);
					} catch (SQLException e) {
						System.out.println("Error adding new member");
						while (e != null) {
							System.out.println("Message: " + e.getMessage());
							e = e.getNextException();
						}
						return;
					}
					
					newMemberStmt.close();

					System.out.println();
					System.out.println("You have registered successfully.");
					System.out.println("Name: " + fName + " " + lName);
					System.out.println("Address: " + sAddress);
					System.out.println("City: " + city);
					System.out.println("Phone: " + phone);
					System.out.println("Email: " + email);
					System.out.println("UserID: " + userID);
					System.out.println("Password: " + password);
					System.out.println("CreditCard Type: " + cardType);
					System.out.println("CreditCard Number: " + cardNumber);
					int var = 0;
					String temp = readEntry("Press enter to go back to Menu ");
					while (var == 0) {
						// Below If statement verifies that User pressed enter
						if (temp.equals("")) {
							input = b1.displayMainMenu();
							var = 1;
						} else {
							System.out.println();
							System.out
									.println("No other key presses besides ENTER are allowed.");
							System.out.println();
							temp = readEntry("Press enter to go back to Menu ");
						}

					}

				} // End of IF block
				else {
					System.out.println();
					System.out
							.println("New member registartion unsuccessful. The userID "
									+ userID
									+ " already exists. Please use a different user ID.");
					System.out.println();
					System.out.println("Please re-enter your information.");
					System.out.println();

				} // End of else block

			} // End of IF block for New Member Registration

			// The following else block ensures that member entered correct
			// options
			else {
				System.out.println("Please enter correct option");
				System.out.println();
				input = b1.displayMainMenu();
			}

		}// End of While loop
		//stmt.close();
		conn.close();
		if (input.equalsIgnoreCase("q")) {
			System.out.println("Thank You for using Online Book Store");
			System.out.println("Have a nice day!!");
			System.exit(0);
		}
	}// End of Main

}// End of class