package genePortalPackage;

import java.sql.*;

import com.mysql.jdbc.Connection;

public class DB_Access_Bean {

	private static String dbusername = "root";
	private static String dbPassword = "";
	private static String dburl = "jdbc:mysql://localhost:3306/";
	private static String dbname = "genedb";
	
	public DB_Access_Bean() {
		// Empty constructor
	}

	public static String getDbusername() {
		return dbusername;
	}

	public static void setDbusername(String dbusername) {
		DB_Access_Bean.dbusername = dbusername;
	}

	public static String getDbPassword() {
		return dbPassword;
	}

	public static void setDbPassword(String dbPassword) {
		DB_Access_Bean.dbPassword = dbPassword;
	}

	public static String getDburl() {
		return dburl;
	}

	public static void setDburl(String dburl) {
		DB_Access_Bean.dburl = dburl;
	}

	public static String getDbname() {
		return dbname;
	}

	public static void setDbname(String dbname) {
		DB_Access_Bean.dbname = dbname;
	}
	
	// Generic function to get information from database
	
public static String getInfoFromDB(String q1) {
		
		String infoFromDB="";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			  String userName = "root";
	            String password = "";
	            String url = "jdbc:mysql://localhost:3306/genedb";
			Connection c1 = (Connection) DriverManager.getConnection(url, userName, password);
			try {
				Statement s1 = c1.createStatement();
				ResultSet rset = s1.executeQuery(q1);
				while (rset.next()) {
					infoFromDB = infoFromDB + rset.getString(1);     // Getting content from one column only
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
			}
			
		} catch (ClassNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		
		return infoFromDB;
		
	}

// Generic function to add New User
public static void addNewUser (String usr, String fname, String lname, String pwd) {

    try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection c1 = (Connection) DriverManager.getConnection(dburl+dbname, dbusername, dbPassword);
                        Statement st = c1.createStatement();
            String query = "insert into user values ('"+usr+"','"+fname+"','"+lname+"','"+pwd+"')";
        try {
            st.executeUpdate(query);

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
            st.close();

    } catch (ClassNotFoundException e) {
        System.out.println(e.getMessage());
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }

} // End of method

public static void addNewNotes (String usr, String notes) {

    try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection c1 = (Connection) DriverManager.getConnection(dburl+dbname, dbusername, dbPassword);
                        Statement st = c1.createStatement();
            String query = "insert into results  values (NULL, CURRENT_DATE(),'" + notes +"','"+usr+"')";
        try {
            st.executeUpdate(query);

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
            st.close();

    } catch (ClassNotFoundException e) {
        System.out.println(e.getMessage());
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }

} // End of method

	
}
