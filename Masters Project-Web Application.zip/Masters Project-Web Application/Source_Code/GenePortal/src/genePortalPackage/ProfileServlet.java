package genePortalPackage;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.algosome.eutils.blast.Blast;
import com.algosome.eutils.blast.BlastParser;
import com.algosome.eutils.blast.GetCommand;
import com.algosome.eutils.blast.PutCommand;

/**
 * Servlet implementation class ProfileServlet
 */
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		String input = null;
		String textBoxInput = null;
		String fileInput = null;

			// Create a factory for disk-based file items
			FileItemFactory factory = new DiskFileItemFactory();

			// Configure a repository (to ensure a secure temp location is used)
			ServletContext servletContext = this.getServletConfig().getServletContext();
			File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
			((DiskFileItemFactory) factory).setRepository(repository);

			// Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);

			// Parse the request
			try {
				List<FileItem> items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
		        for (FileItem item : items) {
		            if (item.isFormField()) {
		            	textBoxInput = item.getString();
		              
		            } else {
		                // Process form file field (input type="file").
		                InputStream fileContent = item.getInputStream();
		                Scanner s = new Scanner(fileContent).useDelimiter("\\A");
		                fileInput = s.hasNext() ? s.next() : "";
		            }
		        }
		    } catch (FileUploadException e) {
		        throw new ServletException("Cannot parse multipart request.", e);
		    }
			
		// Select the correct input
		if (textBoxInput.isEmpty()) {
			input = fileInput;
		}
		else {
			input = textBoxInput;
		}

		//Clean up the input sequence using analyzeString method
		String parsedInput = CPGfinder_Bean.analyzeString(input);
		
		if (input.isEmpty()) {
			request.setAttribute("missingDataMessage", "The input sequence is empty OR does not contain any valid data. Please re-enter data.");
            request.getRequestDispatcher("/profile.jsp").forward(request, response);
		}
		else {
			// Find the GC Count Percentage of overall sequence
			DecimalFormat df1 = new DecimalFormat("#.##");
			double gcP = CPGfinder_Bean.getGC(parsedInput);
			String gcPercentage = df1.format(gcP);
			// Find Count of each neoculotide
			int countA = CPGfinder_Bean.getCountChar(parsedInput, 'A');
			int countG = CPGfinder_Bean.getCountChar(parsedInput, 'G');
			int countT = CPGfinder_Bean.getCountChar(parsedInput, 'T');
			int countC = CPGfinder_Bean.getCountChar(parsedInput, 'C');
			// Find length of input sequence
			int inputLength = parsedInput.length();
			// Set session attributes
			session.setAttribute("inputSequence", parsedInput);
			session.setAttribute("inputGCcount", gcPercentage);
			session.setAttribute("inputAcount", countA);
			session.setAttribute("inputGcount", countG);
			session.setAttribute("inputTcount", countT);
			session.setAttribute("inputCcount", countC);
			session.setAttribute("inputLength", inputLength);
			// Forward to jsp file
			request.getRequestDispatcher("/analyzeInput.jsp").forward(request, response);
		}

	}

}
