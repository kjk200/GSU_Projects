package genePortalPackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(true);

		// This hidden variable to be used for navigation to other pages
		String next = "";
		String choice = request.getParameter("choice");

		if (choice.equals("validateLogin")) {

			PrintWriter out = response.getWriter();
			try {

				String username = request.getParameter("uLogin").toString(); // Retrieve user entered values
				String password = request.getParameter("pLogin").toString();
			
				// Get password for above username from database
				String result = UserAccount_DBbean.getPassword(username); 
				// If entered password matches the database value
				if (password.equals(result)) {
					// setting a global variable for username
					session.setAttribute("current_user", username);
					if (username.equals("admin")) {
						request.getRequestDispatcher("/admin.jsp").forward(request, response);
					}
					else {
						request.getRequestDispatcher("/profile.jsp").forward(request, response);
					}

				
				} 
				// If entered password does not match the database value
				else {

					request.setAttribute("errorMessage", "Incorrect Login. Please enter correct username or password");
					request.getRequestDispatcher("/login.jsp").forward(request, response);
				}



			} finally {
				out.close();
			}

		} // End of If
		
		else if (choice.equals("indexLogin")) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
		else if (choice.equals("profileLogin")) {
			session.setAttribute("saveNotesConf","");
			request.getRequestDispatcher("/profile.jsp").forward(request, response);
		}
	}
}


