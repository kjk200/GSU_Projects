package genePortalPackage;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class BlastServlet
 */
public class BlastServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BlastServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		
		String blastChoice = request.getParameter("blastChoice");
		String blastOutput = null;
		if (blastChoice.equals("orfBlast")) {
			String blastInput = request.getParameter("blastInput");
			if (blastInput.isEmpty()) {
                request.setAttribute("blastErrMsg", "The sequence for Blast can not be empty. Please re-enter the sequence.");
                request.setAttribute("userChoice", "orf");
                request.getRequestDispatcher("/results.jsp").forward(request, response);
			}
			else {
				blastOutput = CPGfinder_Bean.stringBlast(blastInput);
				request.setAttribute("blastTitle1", "Below is the blast output of your sequence");
				request.setAttribute("blastOutput1", blastOutput);
				request.setAttribute("userChoice", "orf");
				request.getRequestDispatcher("/results.jsp").forward(request, response);
			} // End of Else
		
		} // End of If
		if (blastChoice.equals("bothBlast")) {
			String blastInput = request.getParameter("blastInput2");
			if (blastInput.isEmpty()) {
                request.setAttribute("blastErrMsg2", "The sequence for Blast can not be empty. Please re-enter the sequence.");
                request.setAttribute("userChoice", "both");
                request.getRequestDispatcher("/results.jsp").forward(request, response);
			}
			else {
				blastOutput = CPGfinder_Bean.stringBlast(blastInput);
				request.setAttribute("blastTitle2", "Below is the blast output of your sequence");
				request.setAttribute("blastOutput2", blastOutput);
				request.setAttribute("userChoice", "both");
				request.getRequestDispatcher("/results.jsp").forward(request, response);
			} // End of Else
		}

	}

}
