package genePortalPackage;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SaveNotesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public SaveNotesServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);

        String choice = request.getParameter("choice");
        String usr = session.getAttribute("current_user").toString();
        // Add notes to database
        if (choice.equals("cpgSave")) {
        	String userNotes = request.getParameter("cpgNotes");
        	String notes = null;
        	if (userNotes.isEmpty()) {
        		notes = "Performed CPG Island Prediction but no notes were added.";
        	}
        	else{
        		// If more than 4000 characters entered, save first 4000
        		if (userNotes.length()>4000) {
        			notes = userNotes.substring(0, 3999);
        		}
        		else {
        			notes = userNotes;
        		}
        	} // End of Else
        	DB_Access_Bean.addNewNotes(usr, notes);
        	session.setAttribute("saveNotesConf", "Your notes for CPG Analysis have been added. Please continue with your analysis by clicking on below buttons");
        	request.getRequestDispatcher("/analyzeInput.jsp").forward(request, response);
        }
        
        else if (choice.equals("intExSave")) {
        	String userNotes = request.getParameter("intExNotes");
        	String notes = null;
        	if (userNotes.isEmpty()) {
        		notes = "Performed Intron Exon Boundary Prediction but no notes were added.";
        	}
        	else{
        		// If more than 4000 characters entered, save first 4000
        		if (userNotes.length()>4000) {
        			notes = userNotes.substring(0, 3999);
        		}
        		else {
        			notes = userNotes;
        		}
        	} // End of Else
        	DB_Access_Bean.addNewNotes(usr, notes);
        	session.setAttribute("saveNotesConf", "Your notes for Intron Boundary Prediction have been added. Please continue with your analysis by clicking on below buttons");
        	request.getRequestDispatcher("/analyzeInput.jsp").forward(request, response);
        }
        
        else if (choice.equals("blastSave")) {
        	String userNotes = request.getParameter("blastNotes");
        	String notes = null;
        	if (userNotes.isEmpty()) {
        		notes = "Performed BLAST on an input sequence but no notes were added.";
        	}
        	else{
        		// If more than 4000 characters entered, save first 4000
        		if (userNotes.length()>4000) {
        			notes = userNotes.substring(0, 3999);
        		}
        		else {
        			notes = userNotes;
        		}
        	} // End of Else
        	DB_Access_Bean.addNewNotes(usr, notes);
        	session.setAttribute("saveNotesConf", "Your notes for BLAST run have been added. Please continue with your analysis by clicking on below buttons");
        	request.getRequestDispatcher("/analyzeInput.jsp").forward(request, response);
        } // End of else
        
        else if (choice.equals("backToAnalyze")) {
        	session.setAttribute("saveNotesConf","");
        	request.getRequestDispatcher("/analyzeInput.jsp").forward(request, response);
        }
	}     

}
