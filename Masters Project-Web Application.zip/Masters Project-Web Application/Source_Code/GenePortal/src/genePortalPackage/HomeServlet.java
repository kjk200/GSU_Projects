package genePortalPackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class HomeServlet
 */
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public HomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	// Create a new Session or get the current session
    	HttpSession session = request.getSession(true);
    	
    	String navigateTo = "";
    	String choice = request.getParameter("choice");
    	
    	if (choice == null) {
    		navigateTo = "/index.jsp";
    	}
    	else if (choice.equals("login")) {
    		navigateTo = "/login.jsp";
    	}
    	else if (choice.equals("register")) {
    		navigateTo = "/register.jsp";
    	}
    	// Code to navigate to a new jsp page
    	ServletContext sContext = getServletContext();
    	RequestDispatcher rDispatcher = sContext.getRequestDispatcher(navigateTo);
    	rDispatcher.forward(request, response);
    	
	} // End of doPost function

}
