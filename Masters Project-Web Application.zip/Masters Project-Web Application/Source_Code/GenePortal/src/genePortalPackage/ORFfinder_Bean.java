package genePortalPackage;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.Serializable;

import com.algosome.eutils.blast.Blast;
import com.algosome.eutils.blast.BlastParser;
import com.algosome.eutils.blast.GetCommand;
import com.algosome.eutils.blast.PutCommand;

// To allow accessing variables of objects of this class in JSTL
public class ORFfinder_Bean implements Serializable {
	


	public String frameNum;
	public int number;
	public String orf;
	public int length;
	
	public ORFfinder_Bean() {
		// Empty Constructor
	}

	public String getFrameNum() {
		return frameNum;
	}

	public void setFrameNum(String frameNum) {
		this.frameNum = frameNum;
	}
	
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getOrf() {
		return orf;
	}

	public void setOrf(String orf) {
		this.orf = orf;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}
	
	



	public static List<ORFfinder_Bean> getOrfIntervals (String input, String startRegex, String endRegex) {
		
		List<ORFfinder_Bean> output = new ArrayList<ORFfinder_Bean> ();

		//int i = 0;
		int orfCount = 1;
		// Define the six reading frames into a String List
		List<String> readingFrames = new ArrayList<String> ();
		String plus1 = input;
		String plus2 = input.substring(1);
		String plus3 = input.substring(2);
		// Get the complement of the string and reverse it
		String complement = input.replace('A', 'x').replace('C', 'y').replace('G', 'C').replace('T', 'A').replace('x', 'T').replace('y', 'G');
		StringBuilder doReverse = new StringBuilder(complement);
		String reverseComplement = doReverse.reverse().toString();
		// Define the minus frames
		String minus1 = reverseComplement;
		String minus2 = reverseComplement.substring(1);
		String minus3 = reverseComplement.substring(2);
		// Add all 6 frames to a list
		readingFrames.add(plus1);
		readingFrames.add(plus2);
		readingFrames.add(plus3);
		readingFrames.add(minus1);
		readingFrames.add(minus2);
		readingFrames.add(minus3);
		// Set the text for frameNum variable
		for (int r = 0; r<readingFrames.size(); r++) {
			String frameNum = null;
			if (r==0) {
				frameNum = "Frame +1";
			}else if (r==1) {
				frameNum = "Frame +2";
			}
			else if (r==2) {
				frameNum = "Frame +3";
			}
			else if (r==3) {
				frameNum = "Frame -1";
			}
			else if (r==4) {
				frameNum = "Frame -2";
			}
			else if (r==5) {
				frameNum = "Frame -3";
			}
			
			String text = readingFrames.get(r);
			int i = 0;
			int startPos = 0;
			int endPos = 0;
			while ( i < text.length()-2) {
				// Substring for comparing triplets
				String subText = text.substring(i, i+3);
				// Following 3 lines are generic pattern matching
				Pattern startP = Pattern.compile(startRegex);
				Pattern endP = Pattern.compile(endRegex);
				Matcher startM = startP.matcher(subText);
				
				if (startM.find()) {
					// If a match is found, set the start position
					startPos = i;
					for (int j = i; j < text.length()-2; j+=3) {
						String subText2 = text.substring(j, j+3);
						Matcher endM = endP.matcher(subText2);
						if (endM.find()) {
							// If match for end pattern is found, set the end position
							endPos = j+3;
							// Add the string between start and end positions to ArrayList
							ORFfinder_Bean o = new ORFfinder_Bean();
							o.frameNum = frameNum;
							o.number = orfCount;
							o.orf = text.substring(startPos, endPos);
							o.length = text.substring(startPos, endPos).length();
							
							output.add(o);
							orfCount++;
							//output.add("Start: "+startPos+" End: "+endPos);
							i = j;
							break;
						}
					}				
				}
				i = i+3;
				
			}
		}
		
		return output;
		

	}

	
	// To get largest orf sequence
	public static String getLargestORFSequence(List<ORFfinder_Bean> list1) {
		String largestSeq = null;
		int compare = 0;
		for (int i=0; i<list1.size(); i++) {
			if (list1.get(i).getLength() > compare) {
				compare = list1.get(i).getLength();
				largestSeq = list1.get(i).getOrf();
			}
		}
		return largestSeq;
	}
	
	// Run blast
	public static String stringBlast1 (String input) {
		String result = null;
		
		// Create a stream to hold the output
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    PrintStream ps = new PrintStream(baos);
	    //  Save the old System.out!
	    PrintStream old = System.out;
	    // Tell Java to use new output stream
	    System.setOut(ps);			
		// The above steps need to be done because this blast does not provide a method to save result to a string
		PutCommand put = new PutCommand();		
		put.setQuery(input);
		put.setProgram("blastn");
		put.setDatabase("nr");

		//Construct a GetCommand to get the results
		GetCommand get = new GetCommand(new BlastParser() {
			@Override
		 	public void parseBlastOutput(String output) {
				System.out.println(output);


			}
		});

		get.setFormatType("Text");
		//Create the Blast object to run the get and put processes
		Blast blast = new Blast(put, get);
		//Run the alignment. Blast implements Runnable, and can therefore be run in a separate thread.
		blast.run();

	    // Put things back
	    System.out.flush();
	    System.setOut(old);
	    // Convert the output to a string
	    result = baos.toString();
		
		return result;
	}

	
	
} // End of class

