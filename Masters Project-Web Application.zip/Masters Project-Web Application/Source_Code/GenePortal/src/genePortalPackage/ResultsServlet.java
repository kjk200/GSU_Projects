package genePortalPackage;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ResultsServlet
 */
public class ResultsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResultsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);

        // This hidden variable to be used for navigation to other pages
        String next = "";
        String choice = request.getParameter("choice");
        String input = (String) session.getAttribute("inputSequence");
        // If user selects Intron Exon Boundaries
        if (choice.equals("intEx")) {
        	
        	// Declare two lists used for 3" and 5" boundary identifier
        	List<IntronExonIntervals_Bean> output3 = new ArrayList<IntronExonIntervals_Bean>();
        	List<IntronExonIntervals_Bean> output5 = new ArrayList<IntronExonIntervals_Bean>();
        	
        	// Identify the 5" and 3" regular expression
    		String regex5 = "[AGCT]AGGT[AG][A][G]";
    		String regex3 = "([CT]{8}[ACGT][CT]AG[AG][ACGT])";
    		
    		// Run the function to locate intron and exon boundaries
    		output3 = IntronExonIntervals_Bean.getEpigenes(input, regex3);
    		output5 = IntronExonIntervals_Bean.getEpigenes(input, regex5);
    		
    		// Make sure that outputs are always valid and display error messages if no boundaries have been located
    		if (output3.size()>0) {
    			request.setAttribute("checkOutput3", "yes");
    			request.setAttribute("results3", output3);
    		}
    		if (output3.size()==0) {
        		request.setAttribute("checkOutput3", "no");
        		request.setAttribute("noResults3", "No Intron/Exon intervals could be identified in your input sequence from 3\" to 5\".");
    		}
    		if (output5.size()>0) {
    			request.setAttribute("checkOutput5", "yes");
    			request.setAttribute("results5", output5);
    		}
    		if (output3.size()==0) {
        		request.setAttribute("checkOutput5", "no");
        		request.setAttribute("noResults5", "No Intron/Exon intervals could be identified in your input sequence from 5\" to 3\".");
    		}
       	
    		
    		request.setAttribute("userChoice", "intEx");
    		
            request.getRequestDispatcher("/results.jsp").forward(request, response);
        }
        else if (choice.equals("cpg")) {
        	
        	//CPGfinder_Bean cpg1 = new CPGfinder_Bean();
        	List<CPGfinder_Bean> listCPG = new ArrayList<CPGfinder_Bean> ();
        	
        	List <Integer> initialList = CPGfinder_Bean.getInitialCPG (input, 200);
	        List <Integer> parsedList = CPGfinder_Bean.parseList(initialList, 100);
	        List <Integer> finalList = CPGfinder_Bean.finalCPGIslands(parsedList, input, 200);
	        
	        listCPG = CPGfinder_Bean.cpgIslands(finalList, input);
	        
	        if (listCPG.size()>0) {
	        	request.setAttribute("checkCPG1", "yes");
	        	request.setAttribute("CPGresults", listCPG);
	        }
	        else {
	        	request.setAttribute("checkCPG1", "no");
	        	request.setAttribute("noCPG1", "No CPG Islands could be identified in your input sequence.");
	        }

	        request.setAttribute("userChoice", "cpg");
            request.getRequestDispatcher("/results.jsp").forward(request, response);
        }
        else if (choice.equals("blast")) {
        	
        	String blastInput = request.getParameter("blastInput");
        	String blastOutput = null;
        	if (blastInput.isEmpty()) {
        		blastOutput = "Your input sequence is empty. Please enter valid data to view blast results.";
        	}
        	else {
        		blastOutput = CPGfinder_Bean.stringBlast(blastInput);
        	}
 
            request.setAttribute("blastResult", blastOutput);
	        
	        request.setAttribute("userChoice", "blast");
  		
    		request.getRequestDispatcher("/results.jsp").forward(request, response);
	        
        	
        }

	}

}
