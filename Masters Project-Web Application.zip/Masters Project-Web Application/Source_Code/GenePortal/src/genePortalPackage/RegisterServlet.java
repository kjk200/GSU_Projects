package genePortalPackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);

        // This hidden variable to be used for navigation to other pages
        String next = "";
        String choice = request.getParameter("choice");

        if (choice == null) {
            //Open first launch of the application
            next = "/register.jsp";
        } else if (choice.equals("validateRegister")) {

            PrintWriter out = response.getWriter();
            try {

                String username = request.getParameter("uRegister").toString();
                String password = request.getParameter("pRegister");
                String fname = request.getParameter("fRegister");
                String lname = request.getParameter("lRegister");

                String dbPassword = UserAccount_DBbean.getPassword(username);
                // If password exists in DB, implies that username is already taken
                if (!(dbPassword.isEmpty())) {
                     request.setAttribute("statusMessage", "Sorry!! This username is already being used. Please try again.");
                     request.getRequestDispatcher("/register.jsp").forward(request, response);
                }
                // Making sure that none of the required fields can be blank
                else if ((username.isEmpty())||(password.isEmpty())||(fname.isEmpty())||(lname.isEmpty()))  {
                    request.setAttribute("statusMessage", "Please enter values for each field above. None of these can be blank");
                    request.getRequestDispatcher("/register.jsp").forward(request, response);
                }
                // Otherwise, add new user
                else {
                  
                	// Add new user
                	DB_Access_Bean.addNewUser(username, fname, lname, password);
                	
                    session.setAttribute("current_user", username);
                    String success="Your registration is successful!!< Welcome to your profile page!!";
                    request.setAttribute("registerSuccessMessage", success);
                    request.getRequestDispatcher("/profile.jsp").forward(request, response);
                }


            } finally {
                out.close();
            }
        } // End of If-Else
        
		else if (choice.equals("registerLogin")) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
		
		
	}

}
