package genePortalPackage;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IntronExonIntervals_Bean {
	
	// Define attributes
	public int counter;
	public int startIntEx;
	public int endIntEx;
	public String sequenceIntEx;
	
	public IntronExonIntervals_Bean() {
		// Empty constructor
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public int getStartIntEx() {
		return startIntEx;
	}

	public void setStartIntEx(int startIntEx) {
		this.startIntEx = startIntEx;
	}

	public int getEndIntEx() {
		return endIntEx;
	}

	public void setEndIntEx(int endIntEx) {
		this.endIntEx = endIntEx;
	}

	public String getSequenceIntEx() {
		return sequenceIntEx;
	}

	public void setSequenceIntEx(String sequenceIntEx) {
		this.sequenceIntEx = sequenceIntEx;
	}

	public static List<IntronExonIntervals_Bean> getEpigenes(String input, String regex) {
		List<IntronExonIntervals_Bean> output = new ArrayList<IntronExonIntervals_Bean> ();
		// Do pattern matching
		Pattern p1 = Pattern.compile(regex);
		Matcher m1 = p1.matcher(input);
		int counter = 1;
		// If match found
		while (m1.find()) {
			// Declare a new object
			IntronExonIntervals_Bean intEx = new IntronExonIntervals_Bean();
			// Set the properties of this object
			intEx.setCounter(counter);
			intEx.setStartIntEx(m1.start());
			intEx.setEndIntEx(m1.end());
			intEx.setSequenceIntEx(input.substring(m1.start(), m1.end()+1));
			// Add the object to the list
			output.add(intEx);
			// Increment the counter for next addition
			counter++;
			
		}
		// Return the final list
		return output;
	}
	
	

	
}
