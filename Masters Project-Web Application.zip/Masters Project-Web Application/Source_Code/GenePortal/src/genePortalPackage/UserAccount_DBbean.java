package genePortalPackage;

public class UserAccount_DBbean {

	private static String username;

	public static String getUsername() {
		return username;
	}
	
	// Get Password for a specific username
	public static String getPassword (String username) {
		String query = "select pword from user where userid=\""+username+"\"";
		return DB_Access_Bean.getInfoFromDB(query);
	}
	
	// Get First Name for a specific username
	public static String getFirstname (String username) {
		String query = "select fname from user where userid=\""+username+"\"";
		return DB_Access_Bean.getInfoFromDB(query);
	}
	
	// Get Last Name for a specific username
	public static String getLastname (String username) {
		String query = "select lname from user where userid=\""+username+"\"";
		return DB_Access_Bean.getInfoFromDB(query);
	}
	
	
}
