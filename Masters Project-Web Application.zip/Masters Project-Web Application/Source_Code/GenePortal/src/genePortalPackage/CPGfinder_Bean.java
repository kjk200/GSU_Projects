package genePortalPackage;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.algosome.eutils.blast.Blast;
import com.algosome.eutils.blast.BlastParser;
import com.algosome.eutils.blast.GetCommand;
import com.algosome.eutils.blast.PutCommand;

public class CPGfinder_Bean implements Serializable {

	public int cpgCounter;
	public int startInterval;
	public int endInterval;
	public String gcRatioPer;
	public String gcCount;
	public String cpgSequence;

	public CPGfinder_Bean() {
		// Empty Constructor
	}



	public int getCpgCounter() {
		return cpgCounter;
	}



	public void setCpgCounter(int cpgCounter) {
		this.cpgCounter = cpgCounter;
	}



	public int getStartInterval() {
		return startInterval;
	}



	public void setStartInterval(int startInterval) {
		this.startInterval = startInterval;
	}



	public int getEndInterval() {
		return endInterval;
	}



	public void setEndInterval(int endInterval) {
		this.endInterval = endInterval;
	}



	public String getGcRatioPer() {
		return gcRatioPer;
	}



	public void setGcRatioPer(String gcRatioPer) {
		this.gcRatioPer = gcRatioPer;
	}



	public String getGcCount() {
		return gcCount;
	}



	public void setGcCount(String string) {
		this.gcCount = string;
	}



	public String getCpgSequence() {
		return cpgSequence;
	}



	public void setCpgSequence(String cpgSequence) {
		this.cpgSequence = cpgSequence;
	}

	// DEFINE A GENERIC FUNCTION TO GET COUNT OF ANY SINGLE CHAR

	public static int getCountChar (String s, Character c) {
		int count = 0;
		for (int i = 0; i<s.length(); i++) {
			if (s.charAt(i)==c) {
				count++;
			}
		}
		return count;
	}


	// DEFINE GC PERCENTAGE CPG CRITERIA
	public static double getGC (String input) {
		double gcCount = 0.0;
		int gCount = 0;
		int cCount = 0;
		// convert input string into upper case
		input = input.toUpperCase();
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i)=='G') {
				gCount++;
			}
			if (input.charAt(i)=='C') {
				cCount++;
			}
		}
		gcCount = (gCount + cCount)*100.0/(input.length());
		return gcCount;
	}

	//DEFINE OBSERVED/EXPECTED RATIO CPG CRITERIA
	public static double getRatio (String input) {
		double ratio = 0.0;
		int gCount = 0;
		int cCount = 0;
		input = input.toUpperCase();
		// This loop gets g and c counts
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i)=='G') {
				gCount++;
			}
			if (input.charAt(i)=='C') {
				cCount++;
			}
		}
		double expectedGC = (gCount * cCount);
		// find number of 'cg'
		String findStr = "CG";
		int lastIndex = 0;
		int observedGC = 0;

		while(lastIndex != -1){
			// indexOf method gives the index of match and returns -1 if no match is found
			lastIndex = input.indexOf(findStr,lastIndex);
			if( lastIndex != -1){
				observedGC ++;
				lastIndex+=findStr.length();
			}
		}
		ratio = (observedGC / expectedGC) * (input.length() * 1.0) ;	
		return ratio;
	}

	// TEST for gcRatio and gcCount on an input sequence
	public static boolean cpgCriteriaCheck (String input) {
		boolean check = false;
		// Calculate G + C content

		// Test the CPG Criteria here ( needs to be reviewed)
		double gcCount = getGC(input);
		double gcRatio = getRatio(input);
		if ((gcCount > 50.0) && (gcRatio >= 0.61) && (input.length() >=200)){
			check = true;
		}
		return check;
	}
	// CleanUp input String and remove unwanted characters
	public static String analyzeString (String input) {
		String output = null;

		output = input.replaceAll("[-+.^:,]","");
		output = output.replaceAll("(\\r|\\n)", "");
		output = output.toUpperCase();
		output = output.replaceAll("[^ACTG]", "");
		return output;
	}

	// Get initial CPG Count using parameters as input sequence and sliding window width
	public static List<Integer> getInitialCPG (String input, int width) {
		List<Integer> outputList = new ArrayList<Integer> ();
		int i = 0;
		while (i < input.length()) {
			if ((i + width) < input.length()) {
				//check if ORF criteria is met
				boolean checkResult = cpgCriteriaCheck(input.substring(i, i+width));
				if (checkResult) {
					// If criteria is met, add start interval to the output integer list
					outputList.add(i);
					// Add end interval to the output integer list
					outputList.add(i+width);
				}
			}
			// else is for the case of last interval less than 200
			else {

				boolean checkResult = cpgCriteriaCheck(input.substring(i));
				if (checkResult) {
					// Add start and end intervals of remaining sequence if criteria is met
					outputList.add(i);
					outputList.add(i+width);
				}
			}
			// Increment counter
			i++;
		} // End of While
		return outputList;
	} // End of method


	// This method analyzes the initial list and combines neighboring islands
	public static List<Integer> parseList(List<Integer> input, int difference) {
		List<Integer> output = new ArrayList<Integer> ();
		if (input.size() > 0) {
			// always use first element
			int indexToAdd = -1;
			output.add(input.get(0));
			// add second element if input list size is equal to 2
			if ((input.size()==2)) {
				output.add(input.get(1));
			}
			// LOOP THROUGH THE REMAINING LIST
			for (int i = 2; i < input.size(); i+=2) {
				// FOR SUCCESSIVE ELEMENTS
				if ( (input.get(i) - input.get(i-2)) <= difference) {
					// CODING FOR THE LAST TWO ELEMENTS OF INPUT LIST
					if (i >= input.size()-2) {
						//output.add(input.get(i));
						output.add(input.get(i+1));
					}
					// SET INDEX TO i+1
					else { 
						indexToAdd = i+1;
					}
				} // End of If
				else {
					if(indexToAdd != -1) {
						output.add(input.get(indexToAdd));
						indexToAdd = -1;
					} 
					output.add(input.get(i));
					//output.add(input.get(i+1));
				} // End of Else
			} // End of For-Loop
		} // End of first IF
		return output;
	}

	// This method runs the cpgCriteria again on the combined list from parseList method, input sequence and sliding window width
	public static List<Integer> finalCPGIslands(List<Integer> iList, String iSeq, int width) {
		// Declare output list that contains final list of start and end
		// intervals
		List<Integer> oList = new ArrayList<Integer>();
		if(iList.size()==2) {
			// Add the first two elements anyways
			oList.add(iList.get(0));
			oList.add(iList.get(1));
		}
		if (iList.size() > 2) {
			for (int i = 0; i < iList.size()-1; i += 2) {
				// The below IF is attempted to ensure that substring is always valid
				// iSeq is input sequence and iList is output of parseList method
				if (iSeq != null && iList.get(i) >= 0 && iList.get(i+1) >= iList.get(i) && iList.get(i+1) < iSeq.length()) {
					String testSeq = iSeq.substring(iList.get(i),
							iList.get(i + 1) + 1);
					boolean check = cpgCriteriaCheck(testSeq);
					if (check) {
						// If condition is met, add the indexes to the final list
						oList.add(iList.get(i));
						oList.add(iList.get(i + 1));
					}
					// If condition is not met, start removing one character at
					// a time until condition is met
					else {
						int counter = 0;
						int currentSequenceLength = testSeq.length();
						String newTestSeq = null;
						while (counter <= currentSequenceLength) {
							counter++;
							if (testSeq.length() > 2) {
								newTestSeq = testSeq.substring(1,
										testSeq.length() - 1);
								testSeq = newTestSeq;
								if (newTestSeq.length() < width) {
									counter = currentSequenceLength + 1;
								} else {
									boolean checkAgain = cpgCriteriaCheck(newTestSeq);
									// If condition met, add the item to list
									// and exit
									if (checkAgain) {
										oList.add(iList.get(i) + counter);
										oList.add(iList.get(i + 1) - counter);
										counter = currentSequenceLength + 1;
									}

								} // End of Else
							} // End of IF

						} // End of While
					} // End of Else
				}

			} // End of For
		} // End of Else
		return oList;
	}

	// This method returns a list of objects for this class based on final CPG Islands list
	public static List<CPGfinder_Bean> cpgIslands(List <Integer> finalList, String input) {
		List<CPGfinder_Bean> listCPG = new ArrayList<CPGfinder_Bean> ();
		DecimalFormat df = new DecimalFormat("#.##");
		if (finalList.size()==2) {
			double ratio = getRatio(input.substring(finalList.get(0), finalList.get(1)));
			double countPer = getGC(input.substring(finalList.get(0), finalList.get(1)));
			// Create a new object of this class to be added to the output list
			CPGfinder_Bean cpg1 = new CPGfinder_Bean();
			cpg1.setCpgCounter(1);
			cpg1.setStartInterval(finalList.get(0));
			cpg1.setEndInterval(finalList.get(1));
			cpg1.setGcCount(df.format(countPer)+"%");
			cpg1.setGcRatioPer(df.format(ratio));
			cpg1.setCpgSequence(input.substring(finalList.get(0), finalList.get(1)));
			listCPG.add(cpg1);
		} // End of If
		else if (finalList.size()>2) {
			int count=1;
			for (int i = 1; i < finalList.size()-1; i+=2) {
				double ratio = getRatio(input.substring(finalList.get(i-1), finalList.get(i)));
				double countPer = getGC(input.substring(finalList.get(i-1), finalList.get(i)));
				// Create a new object of this class to be added to the output list
				CPGfinder_Bean cpg1 = new CPGfinder_Bean();
				cpg1.setCpgCounter(count);
				cpg1.setStartInterval(finalList.get(i-1));
				cpg1.setEndInterval(finalList.get(i));
				cpg1.setGcCount(df.format(countPer)+"%");
				cpg1.setGcRatioPer(df.format(ratio));
				cpg1.setCpgSequence(input.substring(finalList.get(i-1), finalList.get(i)));
				count++;
				listCPG.add(cpg1);
			}
		}
		return listCPG;
	}
	// To get largest cpg sequence
	public static String getLargestCPGSequence(List<CPGfinder_Bean> list1) {
		String largestSeq = null;
		int compare = 0;
		for (int i=0; i<list1.size(); i++) {
			if (list1.get(i).getCpgSequence().length() > compare) {
				compare = list1.get(i).getCpgSequence().length();
				largestSeq = list1.get(i).getCpgSequence();
			}
		}
		return largestSeq;
	}
	
	// BLAST function
	public static String stringBlast (String input) {
		String result = null;
		// Create a stream to hold the output
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    PrintStream ps = new PrintStream(baos);
	    //  Save the old System.out!
	    PrintStream old = System.out;
	    // Set new output stream
	    System.setOut(ps);			
		// The above steps need to be done because this blast does not provide a method to save result to a string
		PutCommand put = new PutCommand();		
		put.setQuery(input);
		put.setProgram("blastn");
		put.setDatabase("nr");
		//Construct a GetCommand to get the results
		GetCommand get = new GetCommand(new BlastParser() {
			@Override
		 	public void parseBlastOutput(String output) {
				System.out.println(output);
			}
		});
		get.setFormatType("Text");
		//Create the Blast object to run the get and put processes
		Blast blast = new Blast(put, get);
		//Run the alignment. Blast implements Runnable, and can therefore be run in a separate thread.
		blast.run();
	    // Restoring the default settings
	    System.out.flush();
	    System.setOut(old);
	    // Convert the output to a string
	    result = baos.toString();
		return result;
	} // End of method
}
