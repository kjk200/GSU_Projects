

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

// Defining class Engine. The objects of this class will be stored in the main data structure.

class Engine {

    // Variable word is used to store each word from the input files
    // Variable file is used to store the filename of each corresponding word
    String word, file;

    // Empty constructor
    public Engine() {
        
    }

    // Declaring setter method for word variable
    public void setWord (String w) {
        word = w;
    }

    // Declaring setter method for file variable
    public void setFile (String f) {
        file = f;
    }

    // Declaring getter method for word variable
    public String getWord () {
        return word;
    }

    // Declaring getter method for file variable
    public String getFile () {
        return file;
    }

    // The below method is used to load the filenames of input file into a linked List
    public void listInputFiles (final File folder, LinkedList fileList) {
        for (final File fileEntry : folder.listFiles()) {
           if (fileEntry.isDirectory()) {
                  listInputFiles (fileEntry, fileList);
                }
           else {
                    fileList.add(fileEntry.getName());
                }
        }
    }

    // The below method is used to remove any duplicate tokens from an input string
    public String removeDuplicate (String sInput) {
        String s1 =  new LinkedHashSet<String>(Arrays.asList(sInput.split(","))).toString();
        String s2 = s1.substring(1, s1.length()-1);
        return s2;
    }

    // The below method is used to create a linked list for words that need to be ignored
    public LinkedList ignoreTheseWords (String s, LinkedList l) {
        StringTokenizer tk1 = new StringTokenizer(s);
        while (tk1.hasMoreTokens()) {
            l.add(tk1.nextToken().toString());
        }
        return l;
    }

    // The below method is used to find the common tokens from two input strings
    public String findCommon (String s1, String s2) {
        int count = 0;
        String out="";
        String [] s1array = s1.split(",");
        String [] s2array = s2.split(",");
        for (int i=0; i<s1array.length; i++) {
            for (int j=0; j<s2array.length; j++) {
                if (s1array[i].toString().equals(s2array[j].toString())) {
                    out=out+s1array[i].toString();
                    out=out+(",");
                    count++;
                }
            }
        }
        if (count == 0) {
            return out = "No documents exist that meet your input query criteria.";
        }
        else {
            return out;
        }
    }

}

// Declaring the driver class that implements the GUI and invokes methods from Engine class
public class searchEngine extends javax.swing.JFrame {


    // Declaring an object from the Engine class
    Engine e1 = new Engine ();

    // Declaring Linked List to be used to store the filenames
    LinkedList<String> fileList = new LinkedList<String> ();
    // Declaring string variable to be used for finding current directory
    String tempFolder1 = System.getProperty("user.dir");
    // Replacing the single '\' with a double '\\' in the directory path
    String tempFolder2 = tempFolder1.replace("\\", "\\\\");
    // Declaring File variable for the current directory to load input files
    final File folder = new File ( System.getProperty("user.dir"));
    // Declaring Linked List to store words that need to be ignored
    LinkedList <String> ignoreWords = new LinkedList<String> ();
    // Declaring the actual data structure that stores both word and file name
    LinkedList<Engine> myList = new LinkedList<Engine> ();
    // Declaring Linked Lust to store only the words
    LinkedList<String> wordList = new LinkedList<String> ();


    // Creates new form searchEngine
    public searchEngine() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonLOAD = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabelSINGLEKeyword = new javax.swing.JLabel();
        jTextFieldSINGLEKeyword = new javax.swing.JTextField();
        jButtonSINGLEKeyword = new javax.swing.JButton();
        jLabelANDKeyword1 = new javax.swing.JLabel();
        jTextFieldANDKeyword1 = new javax.swing.JTextField();
        jLabelAND = new javax.swing.JLabel();
        jLabelANDKeyword2 = new javax.swing.JLabel();
        jTextFieldANDKeyword2 = new javax.swing.JTextField();
        jButtonAND = new javax.swing.JButton();
        jLabelORKeyword1 = new javax.swing.JLabel();
        jTextFieldORKeyword1 = new javax.swing.JTextField();
        jLabelOR = new javax.swing.JLabel();
        jLabelORKeyword2 = new javax.swing.JLabel();
        jTextFieldORKeyword2 = new javax.swing.JTextField();
        jButtonOR = new javax.swing.JButton();
        jLabelINCOMPLETE = new javax.swing.JLabel();
        jTextFieldINCOMPLETE = new javax.swing.JTextField();
        jButtonINCOMPLETE = new javax.swing.JButton();
        jLabelRESULT = new javax.swing.JLabel();
        jTextFieldRESULT = new javax.swing.JTextField();
        jButtonCLEAR = new javax.swing.JButton();
        jButtonEXIT = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonLOAD.setText("LOAD THE INPUT FILES");
        jButtonLOAD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLOADActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "KOOGLE SEARCH", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jLabelSINGLEKeyword.setText("KEYWORD");

        jButtonSINGLEKeyword.setText("SEARCH");
        jButtonSINGLEKeyword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSINGLEKeywordActionPerformed(evt);
            }
        });

        jLabelANDKeyword1.setText("KEYWORD 1");

        jLabelAND.setText("AND");

        jLabelANDKeyword2.setText("KEYWORD 2");

        jButtonAND.setText("SEARCH");
        jButtonAND.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonANDActionPerformed(evt);
            }
        });

        jLabelORKeyword1.setText("KEYWORD 1");

        jLabelOR.setText("OR");

        jLabelORKeyword2.setText("KEYWORD 2");

        jButtonOR.setText("SEARCH");
        jButtonOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonORActionPerformed(evt);
            }
        });

        jLabelINCOMPLETE.setText("INCOMPLETE KEYWORD");

        jButtonINCOMPLETE.setText("SEARCH");
        jButtonINCOMPLETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonINCOMPLETEActionPerformed(evt);
            }
        });

        jLabelRESULT.setText("RESULT");

        jButtonCLEAR.setText("CLEAR");
        jButtonCLEAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCLEARActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelRESULT)
                        .addGap(32, 32, 32)
                        .addComponent(jTextFieldRESULT, javax.swing.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelINCOMPLETE)
                        .addGap(18, 18, 18)
                        .addComponent(jTextFieldINCOMPLETE, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelSINGLEKeyword)
                        .addGap(18, 18, 18)
                        .addComponent(jTextFieldSINGLEKeyword, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelORKeyword1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextFieldORKeyword1))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelANDKeyword1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextFieldANDKeyword1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelAND)
                            .addComponent(jLabelOR))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelORKeyword2)
                            .addComponent(jLabelANDKeyword2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldORKeyword2, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                            .addComponent(jTextFieldANDKeyword2, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE))))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButtonOR)
                    .addComponent(jButtonINCOMPLETE)
                    .addComponent(jButtonCLEAR)
                    .addComponent(jButtonAND)
                    .addComponent(jButtonSINGLEKeyword))
                .addGap(36, 36, 36))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldSINGLEKeyword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonSINGLEKeyword))
                    .addComponent(jLabelSINGLEKeyword))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelANDKeyword1)
                    .addComponent(jTextFieldANDKeyword1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelAND)
                    .addComponent(jLabelANDKeyword2)
                    .addComponent(jTextFieldANDKeyword2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonAND))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelORKeyword1)
                    .addComponent(jTextFieldORKeyword1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelOR)
                    .addComponent(jLabelORKeyword2)
                    .addComponent(jTextFieldORKeyword2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonOR))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldINCOMPLETE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelINCOMPLETE)
                    .addComponent(jButtonINCOMPLETE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelRESULT)
                    .addComponent(jTextFieldRESULT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonCLEAR))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jButtonEXIT.setText("EXIT");
        jButtonEXIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEXITActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(288, Short.MAX_VALUE)
                .addComponent(jButtonEXIT)
                .addGap(544, 544, 544))
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonLOAD, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButtonLOAD)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonEXIT)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // The below method loads the input files from current directory
    private void jButtonLOADActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLOADActionPerformed
        e1.listInputFiles(folder, fileList);
        // Display the below error message if no input files are available
        if (folder.list().length==1) {
            jTextFieldRESULT.setText("No input files have been loaded. Check your input directory");
        }
        // Setting the list of keywords to be ignored and then reading the input files
        else {
            String ignore = "and if for that this a an is of";
            ignoreWords = e1.ignoreTheseWords(ignore, ignoreWords);
            // Variable word is the actual input word to be store in main data structure
            // Variable caseWord is to be used for storing the lower case equivalent of the input word
            String word, caseWord;
            Scanner s = null;
            // Reading each file from the fileList Linked List
            for (String sFile: fileList) {
                try {
                    // Adding name of the file to directory path
                    String filePath = tempFolder2+"\\"+sFile;
                    // Declaring a file variable
                    File fileName = new File (filePath);
                    // Scanner variable to read the input file
                    s = new Scanner (fileName);
                    // Implementing while loop until end of the file
                    while (s.hasNext()) {

                        word = s.next();
                        caseWord = word.toLowerCase();
                        // Only add if the input word is not contained in the ignore words list
                            if (!(ignoreWords.contains(caseWord))) {
                            // Updating the filename if the word already exists in the data structure
                                if (wordList.contains(caseWord)) {
                                    int index = wordList.indexOf(caseWord);
                                    Engine e2 = myList.get(index);
                                    String w1 = e2.getFile()+","+sFile;
                                    e2.setFile(w1);
                                }
                                // Adding a new word and corresponding filename to the main data structure
                                else {
                                    wordList.add(caseWord);
                                    Engine e3 = new Engine();
                                    e3.setFile(sFile);
                                    e3.setWord(word);
                                    myList.add(e3);

                                }
                            }
                        }
                        // Display the below message if files have been successfully loaded
                        jTextFieldRESULT.setText("Files have been successfuly loaded.");

                    s.close();
                    // Implementing catch block
                    } catch(FileNotFoundException e) {

                        jTextFieldRESULT.setText(e.toString());

                    }
                    // Implementing finally block
                    finally {
                        s.close();
                    }

                }
            }
    }//GEN-LAST:event_jButtonLOADActionPerformed

    // Below method is used to perform a search query with one single keyword
    private void jButtonSINGLEKeywordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSINGLEKeywordActionPerformed
        // Reading the user input keyword
        String key1 = jTextFieldSINGLEKeyword.getText().toLowerCase();
        // Error message if no files have been loaded
        if (folder.list().length==1){
                    jTextFieldRESULT.setText("No input files have been loaded. To load, click on LOAD THE INPUT FILES button.");
                }
        else {
        // Error message if no keywords have been entered
            if ((key1.isEmpty())) {
               jTextFieldRESULT.setText("No keywords have been entered.");
            }
            else {
                // Declaring string variable to store results of this query
                String thisOutput="";

                StringTokenizer token = new StringTokenizer(key1);
                int count = token.countTokens();
                // Checking if only one word has been entered
                if (count == 1) {
                    String sOne = token.nextToken().toString();
                    int index = wordList.indexOf(sOne);
                    if (index==-1) {
                        thisOutput = "No documents match the above input search query.";
                    }
                    else {
                     thisOutput=thisOutput+myList.get(index).getFile();
                    }
                    jTextFieldRESULT.setText(thisOutput);
                }
                // Display the error message if multiple words have been entered for the query
                else {
                jTextFieldRESULT.setText("Only word can be entered in this search criteria.");
                }
    }//GEN-LAST:event_jButtonSINGLEKeywordActionPerformed
        }
    } // End of function

    // The below method implements search query using AND function with two keyword
        private void jButtonANDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonANDActionPerformed
            // Variables keyword1 and keyword2 are used to store the user keywords
            String keyword1 = jTextFieldANDKeyword1.getText().toLowerCase();
            String keyword2 = jTextFieldANDKeyword2.getText().toLowerCase();
            String response ="";
            // Display this error message if no files have been loaded yet
            if (folder.list().length==1){
                jTextFieldRESULT.setText("No input files have been loaded. To load, click on LOAD THE INPUT FILES button.");
            }
            else {
                // Display this error message if two keywords have not been entered
                if ((keyword1.isEmpty())||(keyword2.isEmpty())) {
                    jTextFieldRESULT.setText("To run this query, make sure to enter two keywords");
                }
                else {
                    int firstIndex = wordList.indexOf(keyword1);
                    int secondIndex = wordList.indexOf(keyword2);
                    if ((firstIndex==-1) || (secondIndex ==-1)) {
                    jTextFieldRESULT.setText("No documents match the above input search query.");
                    }
                    else {
                        Engine eFirst = myList.get(firstIndex);
                        Engine eSecond = myList.get(secondIndex);
                        // Variable s1 and s2 get the list of files that contain each of the keywords
                        String s1 = eFirst.getFile();
                        String s2 = eSecond.getFile();
                        // Using the fincCommon method to identify the files that contain both these words
                        response = e1.findCommon(s1, s2);
                        if (response.endsWith(",")) {
                            response = response.substring(0, response.length()-1);
                        }
                        jTextFieldRESULT.setText(response);
                   }

                }
            }
        }//GEN-LAST:event_jButtonANDActionPerformed

        // The below method implements search query using OR function with two keywords
        private void jButtonORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonORActionPerformed
           
            // Variables keyword1 and keyword2 are used to store input words
            String keyword1 = jTextFieldORKeyword1.getText().toLowerCase();
            String keyword2 = jTextFieldORKeyword2.getText().toLowerCase();
            // Initializing this variable to store the result
            String response ="";
                // Display this error message if no input files have been loaded
                if (folder.list().length==1){
                    jTextFieldRESULT.setText("No input files have been loaded. To load, click on LOAD THE INPUT FILES button.");
                }
                else {
                    // Display this error message if two keywords have not been entered
                    if ((keyword1.isEmpty())||(keyword2.isEmpty())) {
                        jTextFieldRESULT.setText("To run this query, make sure to enter two keywords");
                    }
                    else {
                         int firstIndex = wordList.indexOf(keyword1);
                         int secondIndex = wordList.indexOf(keyword2);

                         if ((firstIndex==-1) && (secondIndex ==-1)) {
                            jTextFieldRESULT.setText("No documents match the above input search query.");
                         }
                         else if ((firstIndex==-1)&&(secondIndex!=-1)) {
                             jTextFieldRESULT.setText(myList.get(secondIndex).getFile());
                         }
                         else if ((firstIndex!=-1)&&((secondIndex==-1))) {
                             jTextFieldRESULT.setText(myList.get(firstIndex).getFile());
                         }
                         else {
                         Engine eFirst = myList.get(firstIndex);
                         Engine eSecond = myList.get(secondIndex);
                         String s1 = eFirst.getFile();
                         String s2 = eSecond.getFile();
                         response = s1 + "," + s2;
                         // Using the removeDuplicate method to remove any duplicate file names
                         response = e1.removeDuplicate(response);
                         if (response.endsWith(",")) {
                             response=response.substring(0, response.length()-1);
                         }
                       jTextFieldRESULT.setText(response);
                         }
                    }
                }
        }//GEN-LAST:event_jButtonORActionPerformed

        // The below method implements incomplete keyword search query
        private void jButtonINCOMPLETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonINCOMPLETEActionPerformed
            // Using variable keyword1 to store the input word
            String keyword1 = jTextFieldINCOMPLETE.getText().toLowerCase();
            String response ="";
            String subquery ="";
            // Display the error message if no input files have been loaded
            if (folder.list().length==1){
                jTextFieldRESULT.setText("No input files have been loaded. To load, click on LOAD THE INPUT FILES button.");
            }
            else {
                // Display this error message if keyword is empty
                if (keyword1.isEmpty()) {
                    jTextFieldRESULT.setText("To run this query, enter an incomplete keyword in the format xyz*");
                }
                // Display this error message if the keyword is not in the correct format
                else if (!(keyword1.contains("*"))) {
                    jTextFieldRESULT.setText("To run this query, enter an incomplete wildcard in the format xyz*");
                }
                else {
                    // Creating a substring of the keyword prior to * character
                    String query = keyword1.substring(0,keyword1.indexOf("*"));
                    for (String w: wordList) {
                        if (w.startsWith(query)) {
                            // Adding each matching word to the string variable
                            subquery = subquery+w;
                            subquery = subquery+" ";
                        }
                    }
                    // Tokenizing the subquery to search filenames for each token
                    StringTokenizer token = new StringTokenizer(subquery);
                    while (token.hasMoreTokens()) {
                        String tokenWord = token.nextToken().toString();
                        int index = wordList.indexOf(tokenWord);
                        Engine eKey = myList.get(index);
                        response = response+eKey.getFile();
                        response = response+",";

                    }
                    // Using the removeDuplicate method to remove any duplicate file names
                    response = e1.removeDuplicate(response);
                    if (response.endsWith(",")) {
                                response = response.substring(0, response.length()-1);
                    }
                    if (response.isEmpty()) {
                        jTextFieldRESULT.setText("No documents match your search query");
                    }
                    else {
                       jTextFieldRESULT.setText(response);
                    }
                            
                }

            }

        }//GEN-LAST:event_jButtonINCOMPLETEActionPerformed

        // The below method clears all the values from text fields in the GUI
        private void jButtonCLEARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCLEARActionPerformed
            jTextFieldSINGLEKeyword.setText("");
        jTextFieldANDKeyword1.setText("");
        jTextFieldANDKeyword2.setText("");
        jTextFieldORKeyword1.setText("");
        jTextFieldORKeyword2.setText("");
        jTextFieldRESULT.setText("");
        jTextFieldINCOMPLETE.setText("");
        }//GEN-LAST:event_jButtonCLEARActionPerformed

        // The below method implements Exit button behavior
        private void jButtonEXITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEXITActionPerformed
            System.exit(0);
        }//GEN-LAST:event_jButtonEXITActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new searchEngine().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAND;
    private javax.swing.JButton jButtonCLEAR;
    private javax.swing.JButton jButtonEXIT;
    private javax.swing.JButton jButtonINCOMPLETE;
    private javax.swing.JButton jButtonLOAD;
    private javax.swing.JButton jButtonOR;
    private javax.swing.JButton jButtonSINGLEKeyword;
    private javax.swing.JLabel jLabelAND;
    private javax.swing.JLabel jLabelANDKeyword1;
    private javax.swing.JLabel jLabelANDKeyword2;
    private javax.swing.JLabel jLabelINCOMPLETE;
    private javax.swing.JLabel jLabelOR;
    private javax.swing.JLabel jLabelORKeyword1;
    private javax.swing.JLabel jLabelORKeyword2;
    private javax.swing.JLabel jLabelRESULT;
    private javax.swing.JLabel jLabelSINGLEKeyword;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextFieldANDKeyword1;
    private javax.swing.JTextField jTextFieldANDKeyword2;
    private javax.swing.JTextField jTextFieldINCOMPLETE;
    private javax.swing.JTextField jTextFieldORKeyword1;
    private javax.swing.JTextField jTextFieldORKeyword2;
    private javax.swing.JTextField jTextFieldRESULT;
    private javax.swing.JTextField jTextFieldSINGLEKeyword;
    // End of variables declaration//GEN-END:variables

}
