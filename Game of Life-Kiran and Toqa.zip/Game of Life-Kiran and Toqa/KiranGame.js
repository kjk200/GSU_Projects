var simulate= false;
var grid_width = 30;
var grid_height = 20;
var speed = 1;
var generation_count;
var current_array;
var next_array;
var flag_array;
var alive_Cell_Count=0;


// Default table that displays upon opening the page
function default_table()
{
	document.getElementById("xAxis").value = grid_width;
	document.getElementById("yAxis").value = grid_height;
	clearGrid();
}
// User  Defined table
function grid_dimensions()
{
	grid_width = document.getElementById("xAxis").value;
	grid_height = document.getElementById("yAxis").value;
	clearGrid();	
}

// Reset Game
function clearGrid()
{
	simulate= false;
	generation_count= 0;
	create_Arrays();
	create_World();
	document.getElementById("h2").innerHTML = "Number of Alive Cells: 0";
	display_genCount();
}

// Create 3 arreays to store current, next and flag patterns
function create_Arrays()
{
	current_array = new Array(grid_width);
	next_array = new Array(grid_width);
	flag_array = new Array(grid_width);
	for (var x = 0; x < grid_width; x++) {
		current_array[x] = new Array(grid_height);
		next_array[x] = new Array(grid_height);
		flag_array[x] = new Array(grid_height);
		for (var y = 0; y < grid_height; y++) {
			current_array[x][y] = false;
			next_array[x][y] = false;
			flag_array[x][y] = false;
		}
	}
}


// Add rows and colummns to the table
function create_World()
{
//Delete any existing rows
	var world_grid = document.getElementById("world");
	var number_rows = world_grid.rows.length;
	for (var y = 0; y < number_rows; y++) {
		world_grid.deleteRow(-1);
	}

// Add new rows
	for (var y = 0; y < grid_height; y++) {
		var row = world_grid.insertRow(-1);
		for (var x = 0; x < grid_width; x++) {
			var cell = row.insertCell(-1);
			cell.className = "cell";
			cell.innerHTML = "&nbsp;";
			cell.x = x;
			cell.y = y;
			cell.alive = "false";
			cell.onclick = changeState;
		}
	}
	generation_count= 0;
}

// Display Generation count
function display_genCount()
{
	document.getElementById("h1").innerHTML = "Generation Count is: "+generation_count;
}

// Code for the start button
function lets_play()
{
	simulate = true;//!(simulate);

	document.getElementById("setButton").disabled = simulate;
	document.getElementById("xAxis").disabled = simulate;
	document.getElementById("yAxis").disabled = simulate;
	document.getElementById("resetButton").disabled = simulate;
	document.getElementById("startButton").disabled = simulate;
	document.getElementById("incOne").disabled = simulate;
	document.getElementById("inc23").disabled = simulate;
	if (simulate) {
		play();
	}	
}
// Code for 1 generation increment
function increment_oneGen()
{
	simulate= false;
	play();
}

// Code for 23 generation increment
function increment_23Gen() 
{
	simulate = false;
	for (var c = 0; c<23; c++) {
		play();
	}
}

// Code for making a cell alive or dead by clicking it
function changeState(evt)
{
	var cell = evt.target;
	if (cell.alive == "false") {
		cell.alive = "true";
		cell.style.backgroundColor = "red";
		current_array[cell.x][cell.y] = true;
	} 
	else {
		cell.alive = "false";
		cell.style.backgroundColor = "lightblue";
		current_array[cell.x][cell.y] = false;
	}
}

// Actual code that runs the game
function play()
{
	generation_count++;
	next_State();
	make_Grid();
	display_genCount();
	if (simulate) {
		setTimeout("play();", 100 * speed);
	}

	alive_Cell_Count = count_AliveCells();
	document.getElementById("h2").innerHTML = "Number of Alive Cells: "+alive_Cell_Count;
}

// Calculate next generation of the game
function next_State()
{
	for (var x = 0; x < grid_width; x++) {
		for (var y = 0; y < grid_height; y++) {
			next_array[x][y] = false;
			flag_array[x][y] = false;
		}
	}
	for (var y = 0; y < grid_height; y++) {
		for (var x = 0; x < grid_width; x++) {
			var alive_now = current_array[x][y];
			var alive_then = false;
			var number_neighbors = get_Neighbors(x, y);

			if ((alive_now) && (number_neighbors < 2))
			{
				alive_then = false;
			}
			else if ((alive_now) && (number_neighbors > 3))
			{
				alive_then = false;
			}
			else if ((!alive_now) && (number_neighbors == 3))
			{
				alive_then = true;
			}
			else if ((alive_now) && ((number_neighbors == 2) || (number_neighbors == 3)))
			{
				alive_then = true;
			}
			next_array[x][y] = alive_then;
			flag_array[x][y] = (alive_now != alive_then);
		}
	}
	for (var x = 0; x < grid_width; x++) {
		for (var y = 0; y < grid_height; y++) {
			current_array[x][y] = next_array[x][y];
		}
	}
}


// Populate the grid
function make_Grid()
{
	var world_grid = document.getElementById("world");
	for (var y = 0; y < grid_height; y++) {
		var cells = world_grid.rows[y].cells;
		for (var x = 0; x < grid_width; x++) {
			if (flag_array[x][y]) {
				cells[x].style.backgroundColor = (current_array[x][y]) ? "red" : "lightblue";
			}
		}
	}
}

// Count the number of neighbors for each cell
function get_Neighbors(x, y)
{
	var n = 0;
	if (isAlive(x-1, y-1)) n++;
	if (isAlive(x-1, y)) n++;
	if (isAlive(x-1, y+1)) n++;
	if (isAlive(x, y-1)) n++;
	if (isAlive(x, y+1)) n++;
	if (isAlive(x+1, y-1)) n++;
	if (isAlive(x+1, y)) n++;
	if (isAlive(x+1, y+1)) n++;
	return n;
}

// Code to check whether a cell is alive
function isAlive(x, y)
{
	var alive = false;
	if ((x >= 0) && (x < grid_width) && (y >= 0) && (y < grid_height)) {
		alive = current_array[x][y];
	} 
	else {
		alive = false;
	}
		return alive;
}

// Count the number of alive cells
function count_AliveCells() 
{
	var alive_Count = 0;
	for (var y = 0; y < grid_height; y++) {
		for (var x = 0; x < grid_width; x++) {
			if (current_array[x][y]) {
				alive_Count++;
			}
		}
	}
return alive_Count;
}

// Code for the Stop Button
function stop_Button() {

	simulate = false;;
	document.getElementById("setButton").disabled = simulate;
	document.getElementById("xAxis").disabled = simulate;
	document.getElementById("yAxis").disabled = simulate;
	document.getElementById("resetButton").disabled = simulate;
	document.getElementById("startButton").disabled = simulate;
	document.getElementById("incOne").disabled = simulate;
	document.getElementById("inc23").disabled = simulate;
}

// Code for selecting a random pattern
function select_Random() {
 
	var p = new Array();
	var q = new Array();
	var max = Math.max(grid_height , grid_width);
	var limit = (Math.floor(Math.random()*max)+1);
	 
	for (var i=0; i<max; i++) {
		p[i] = (Math.floor(Math.random()*grid_height));
		q[i] = (Math.floor(Math.random()*grid_width));
	}
	
	for (var i=0;i<max;i++){
		current_array[q[i]][p[i]] = true;
		flag_array[q[i]][p[i]] = true;
	}

	make_Grid();
}

// Code for generating a random pattern
function random_Pattern() {
	clearGrid();
	for (var i=0; i<5; i++) {
		setTimeout("select_Random();", 10 * speed);
	}
}


// Code for the glider pattern
function glider_Pattern() {
// Setting the grid for best simulation of this pattern
	grid_width = 50;
	grid_height = 40;

	clearGrid();
	document.getElementById("xAxis").value = grid_width;
	document.getElementById("yAxis").value = grid_height;

	var g1 = new Array();
	var g2 = new Array();

	g2 = [2,2,3,3,12,12,12,13,13,14,14,15,15,16,17,17,18,18,18,19,22,22,22,23,23,23,24,24,26,26,26,26,36,36,37,37];
	g1 = [6,7,6,7,6,7,8,5,9,4,10,4,10,7,5,9,6,7,8,7,4,5,6,4,5,6,3,7,2,3,7,8,4,5,4,5];
	
	for (var i=0;i<g1.length;i++){
		current_array[g2[i]][g1[i]] = true;
		flag_array[g2[i]][g1[i]] = true;		 
	}
	make_Grid();
}

// Code for Puff Train pattern
function puff_train() {
// Setting the grid for best simulation of this pattern
	grid_width = 60;
	grid_height =30;
	clearGrid();
	document.getElementById("xAxis").value = grid_width;
	document.getElementById("yAxis").value = grid_height;

	var g1 = new Array();
	var g2 = new Array();

	g2 = [6,7,3,7,4,5,6,7,3,4,5,5,5,4,6,7,3,7,4,5,6,7];
	g1 = [3,4,5,5,6,6,6,6,10,11,11,12,13,14,17,18,19,19,20,20,20,20];
	for (var i=0;i<g1.length;i++){
		current_array[g2[i]][g1[i]] = true;
		flag_array[g2[i]][g1[i]] = true;
	}
	make_Grid();	
}


// Below function is used for the drop down menu of special well-known patterns
function patternSelect(){

	var pattern= document.getElementById("myList").value;
		switch (pattern){
		case "Random":
			random_Pattern(); break;
		case "Gosper Glider Gun":
			glider_Pattern(); break;
		case "Puff Train":
			puff_train(); break;
	}
}